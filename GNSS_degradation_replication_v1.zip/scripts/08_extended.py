"""Extended analyses.

A. Airport terminal-area exposure (OurAirports, scheduled-service airports).
B. Episode durations (Kaplan-Meier) by region.
C. Distance decay of spatial contagion (k-ring shells 1-3), two-way FE.
D. Dynamic (weekly) event studies with HAC 95% CIs and pre-trend tests.
E. Out-of-sample next-day nowcasting (train 2022-2025, test 2026): ROC/AUC.
"""
from pathlib import Path

import h3
import numpy as np
import pandas as pd
import scipy.sparse as sp
import statsmodels.formula.api as smf

ROOT = Path(__file__).resolve().parents[1]
DER = ROOT / "data" / "derived"
RES = ROOT / "results"
MAN = pd.read_csv(ROOT / "data" / "raw" / "gpsjam_manifest.csv", parse_dates=["date"])
SUSPECT = set(MAN.loc[MAN.suspect, "date"])


# ---------------------------------------------------------------- dense focus array
def dense_focus():
    f = pd.read_parquet(DER / "hexday_focus.parquet")
    f = f[~f.date.isin(SUSPECT)]
    hexes = np.sort(f.hex.unique())
    dates = pd.DatetimeIndex(sorted(MAN.date[~MAN.date.isin(SUSPECT)]))
    # keep full calendar so t-1 means the previous calendar day
    cal = pd.date_range(dates.min(), dates.max(), freq="D")
    hi = pd.Series(np.arange(len(hexes)), index=hexes)
    ti = pd.Series(np.arange(len(cal)), index=cal)
    R = np.full((len(hexes), len(cal)), np.nan, dtype=np.float32)
    R[hi[f.hex].values, ti[f.date].values] = f.red.values
    meta = f.drop_duplicates("hex").set_index("hex").loc[hexes, ["region", "iso3"]].reset_index()
    return R, hexes, cal, meta


def ring_matrix(hexes, k):
    idx = {h: i for i, h in enumerate(hexes)}
    rows, cols = [], []
    for i, h in enumerate(hexes):
        for n in h3.grid_ring(h3.int_to_str(int(h)), k):
            j = idx.get(h3.str_to_int(n))
            if j is not None:
                rows.append(i); cols.append(j)
    return sp.csr_matrix((np.ones(len(rows), dtype=np.float32), (rows, cols)), shape=(len(hexes), len(hexes)))


def build_long(R, hexes, cal, meta):
    obs = (~np.isnan(R)).astype(np.float32)
    red0 = np.nan_to_num(R)
    shares, counts = {}, {}
    for k in (1, 2, 3):
        A = ring_matrix(hexes, k)
        s, c = A @ red0, A @ obs
        with np.errstate(invalid="ignore", divide="ignore"):
            shares[k] = np.where(c > 0, s / c, np.nan)
        counts[k] = c
    # own 7-day frequency over t-7..t-1
    cs_red = np.nancumsum(np.nan_to_num(R), axis=1)
    cs_obs = np.cumsum(obs, axis=1)
    def lagwin(cs, w=7):
        out = np.full(cs.shape, np.nan, dtype=np.float32)
        out[:, w + 1:] = cs[:, w:-1] - cs[:, :-w - 1]
        return out
    with np.errstate(invalid="ignore", divide="ignore"):
        freq7 = lagwin(cs_red) / lagwin(cs_obs)
    ii, tt = np.where(~np.isnan(R[:, 1:]) & ~np.isnan(R[:, :-1]))
    tt = tt + 1
    d = pd.DataFrame({"h": ii, "t": tt, "red": R[ii, tt], "prev": R[ii, tt - 1],
                      "s1": shares[1][ii, tt - 1], "s2": shares[2][ii, tt - 1], "s3": shares[3][ii, tt - 1],
                      "c1": counts[1][ii, tt - 1], "c2": counts[2][ii, tt - 1], "c3": counts[3][ii, tt - 1],
                      "freq7": freq7[ii, tt]})
    d["date"] = cal[d.t.values]
    d["region"] = meta.region.values[d.h.values]
    d.loc[meta.iso3.values[d.h.values] == "TUR", "region"] = d.loc[meta.iso3.values[d.h.values] == "TUR", "region"]
    return d


# ---------------------------------------------------------------- C. distance decay
def distance_decay(d):
    import pyfixest as pf
    x = d[(d.c1 >= 2) & (d.c2 >= 3) & (d.c3 >= 3)].copy()
    x["red100"] = 100 * x.red
    x["reg_date"] = x.region + "_" + x.date.dt.strftime("%Y%m%d")
    out = []
    for name, sub in [("onset", x[x.prev == 0]), ("persistence", x[x.prev == 1])]:
        m = pf.feols("red100 ~ s1 + s2 + s3 | h + reg_date", data=sub, vcov={"CRV1": "h"})
        t = m.tidy().reset_index(); t["sample"] = name; t["nobs"] = m._N
        out.append(t)
    pd.concat(out).to_csv(RES / "distance_decay_fe.csv", index=False)


# ---------------------------------------------------------------- E. nowcasting
def nowcast(d):
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import brier_score_loss, roc_auc_score, roc_curve
    x = d[d.c1 >= 1].copy()
    for c in ["s1", "s2", "s3", "freq7"]:
        x[c + "_na"] = x[c].isna().astype(float)
        x[c] = x[c].fillna(0)
    feats = ["prev", "s1", "s2", "s3", "freq7", "s2_na", "s3_na", "freq7_na"]
    train = x[x.date < "2026-01-01"]
    test = x[x.date >= "2026-01-01"]
    tr = train.sample(n=min(3_000_000, len(train)), random_state=1)
    models = {"Persistence only (red at t−1)": ["prev"],
              "Own history (t−1 and 7-day frequency)": ["prev", "freq7", "freq7_na"],
              "Full: own history + neighbourhood rings 1–3": feats}
    rows, curves = [], []
    for name, fs in models.items():
        lr = LogisticRegression(max_iter=500)
        lr.fit(tr[fs], tr.red)
        p = lr.predict_proba(test[fs])[:, 1]
        auc = roc_auc_score(test.red, p)
        fpr, tpr, _ = roc_curve(test.red, p)
        sel = np.linspace(0, len(fpr) - 1, min(400, len(fpr))).astype(int)
        curves.append(pd.DataFrame({"model": name, "fpr": fpr[sel], "tpr": tpr[sel]}))
        rows.append(dict(model=name, region="All focal", auc=auc, brier=brier_score_loss(test.red, p),
                         n_test=len(test), base_rate=test.red.mean()))
        if name.startswith("Full"):
            for reg, g in test.assign(p=p).groupby("region"):
                if g.red.nunique() == 2 and g.red.sum() >= 50:
                    rows.append(dict(model=name, region=reg, auc=roc_auc_score(g.red, g.p),
                                     brier=brier_score_loss(g.red, g.p), n_test=len(g), base_rate=g.red.mean()))
            coefs = pd.Series(lr.coef_[0], index=fs)
            coefs.to_csv(RES / "nowcast_coefficients.csv")
    pd.DataFrame(rows).to_csv(RES / "nowcast_auc.csv", index=False)
    pd.concat(curves).to_csv(RES / "nowcast_roc.csv", index=False)


# ---------------------------------------------------------------- B. episodes
def episodes(R, meta, cal):
    recs = []
    nH, nT = R.shape
    for i in range(nH):
        r = R[i]
        t = 0
        while t < nT:
            if r[t] == 1 and (t == 0 or r[t - 1] != 1):
                start = t
                while t + 1 < nT and r[t + 1] == 1:
                    t += 1
                end = t
                nxt = r[end + 1] if end + 1 < nT else np.nan
                event = 1 if nxt == 0 else 0  # censored if next day unobserved / end of data
                recs.append((i, start, end - start + 1, event))
            t += 1
    e = pd.DataFrame(recs, columns=["h", "start", "dur", "event"])
    e["region"] = meta.region.values[e.h.values]
    e["iso3"] = meta.iso3.values[e.h.values]
    e["year"] = cal[e.start.values].year
    e.to_csv(DER / "episodes.csv", index=False)
    rows, curves = [], []
    for reg, g in list(e.groupby("region")) + [("All focal", e)]:
        km = kaplan_meier(g.dur.values, g.event.values)
        med = km.loc[km.S <= 0.5, "t"].min()
        s7 = km.loc[km.t <= 7, "S"].min() if (km.t <= 7).any() else 1.0
        s30 = km.loc[km.t <= 30, "S"].min() if (km.t <= 30).any() else 1.0
        rows.append(dict(region=reg, episodes=len(g), censored_share=1 - g.event.mean(), median_days=med,
                         S_gt7=s7, S_gt30=s30, mean_dur=g.dur.mean(), max_dur=g.dur.max()))
        curves.append(km.assign(region=reg))
    pd.DataFrame(rows).to_csv(RES / "episodes_km.csv", index=False)
    pd.concat(curves).to_csv(RES / "episodes_km_curves.csv", index=False)


def kaplan_meier(dur, event):
    df = pd.DataFrame({"d": dur, "e": event})
    ts = np.sort(df.d.unique())
    n_at_risk = np.array([(df.d >= t).sum() for t in ts])
    d_events = np.array([((df.d == t) & (df.e == 1)).sum() for t in ts])
    S = np.cumprod(1 - d_events / n_at_risk)
    return pd.DataFrame({"t": ts, "S": S, "n": n_at_risk})


# ---------------------------------------------------------------- D. dynamic event studies
def dynamic_events():
    d = pd.read_csv(DER / "daily_region.csv", parse_dates=["date"])
    d = d[~d.suspect.fillna(False)]
    ev = [("2023-10-07", "Levant core"), ("2025-05-07", "South Asia (Ind-Pak)"), ("2025-06-13", "Persian Gulf"),
          ("2026-02-28", "Levant core"), ("2026-02-28", "Eastern Mediterranean"), ("2026-02-28", "Persian Gulf")]
    rows = []
    for date, reg in ev:
        t0 = pd.Timestamp(date)
        s = d[(d.region == reg) & (d.date >= t0 - pd.Timedelta(days=84)) & (d.date < t0 + pd.Timedelta(days=84))].copy()
        s["w"] = ((s.date - t0).dt.days // 7).astype(int)
        s["y"] = 100 * s.share_red
        s["dow"] = s.date.dt.dayofweek.astype(str)
        # full set of week effects (no intercept); each week contrasted with the pre-event mean
        m = smf.ols("y ~ C(w) + C(dow) - 1", data=s).fit(cov_type="HAC", cov_kwds={"maxlags": 14})
        names = list(m.params.index)
        wk = {int(c.split("[")[1].rstrip("]")): names.index(c) for c in names if c.startswith("C(w)")}
        pre_w = [w for w in wk if w < 0]
        for w, j in sorted(wk.items()):
            L = np.zeros(len(names))
            L[j] += 1
            for pw in pre_w:
                L[wk[pw]] -= 1 / len(pre_w)
            tt = m.t_test(L)
            ci = np.asarray(tt.conf_int()).ravel()
            rows.append(dict(event=date, region=reg, week=w, coef=float(np.asarray(tt.effect).ravel()[0]),
                             lo=ci[0], hi=ci[1], p=float(np.asarray(tt.pvalue).ravel()[0])))
        # post-event average contrast
        L = np.zeros(len(names))
        post_w = [w for w in wk if w >= 0]
        for w in post_w:
            L[wk[w]] += 1 / len(post_w)
        for w in pre_w:
            L[wk[w]] -= 1 / len(pre_w)
        tt = m.t_test(L)
        rows.append(dict(event=date, region=reg, week=99, coef=float(np.asarray(tt.effect).ravel()[0]),
                         lo=np.asarray(tt.conf_int()).ravel()[0], hi=np.asarray(tt.conf_int()).ravel()[1],
                         p=float(np.asarray(tt.pvalue).ravel()[0])))
    pd.DataFrame(rows).sort_values(["event", "region", "week"]).to_csv(RES / "dynamic_events.csv", index=False)


# ---------------------------------------------------------------- A. airports
def airports():
    ap = pd.read_csv(ROOT / "data" / "raw" / "ourairports_airports.csv", low_memory=False)
    ap = ap[ap.type.isin(["large_airport", "medium_airport"]) & (ap.scheduled_service == "yes")].copy()
    ap["cell"] = [h3.str_to_int(h3.latlng_to_cell(a, b, 4)) for a, b in zip(ap.latitude_deg, ap.longitude_deg)]
    foot = [(r.ident, h3.str_to_int(c)) for r in ap.itertuples() for c in h3.grid_disk(h3.int_to_str(int(r.cell)), 1)]
    foot = pd.DataFrame(foot, columns=["ident", "hex"])
    p = pd.read_parquet(ROOT / "data" / "panel.parquet", filters=[("hex", "in", list(set(foot.hex)))])
    p = p[~p.date.isin(SUSPECT)]
    p["n"] = p.good + p.bad
    p = p[p.n >= 3]
    p["red"] = (100 * (p.bad - 1).clip(lower=0) / p.n > 10).astype(int)
    x = foot.merge(p[["date", "hex", "red", "n", "bad"]], on="hex")
    x["n_red"] = x.n * x.red
    ad = x.groupby(["ident", "date"]).agg(red_any=("red", "max"), n=("n", "sum"), n_red=("n_red", "sum")).reset_index()
    ad["year"] = ad.date.dt.year
    ay = ad.groupby(["ident", "year"]).agg(days_obs=("date", "size"), days_red=("red_any", "sum"),
                                           ac=("n", "sum"), ac_red=("n_red", "sum")).reset_index()
    ay = ay[ay.days_obs >= 30]
    ay["share_days"] = ay.days_red / ay.days_obs
    ay["share_aircraft"] = ay.ac_red / ay.ac
    ay = ay.merge(ap[["ident", "name", "type", "iso_country", "municipality", "iata_code", "latitude_deg", "longitude_deg"]], on="ident")
    ay.to_csv(RES / "airport_year_exposure.csv", index=False)
    cnt = ay.groupby("year").agg(airports=("ident", "nunique"),
                                 ge10=("share_days", lambda s: (s >= 0.10).sum()),
                                 ge50=("share_days", lambda s: (s >= 0.50).sum())).reset_index()
    big = ay[ay.type == "large_airport"].groupby("year").agg(large=("ident", "nunique"),
                                                             large_ge10=("share_days", lambda s: (s >= 0.10).sum())).reset_index()
    cnt.merge(big, on="year").to_csv(RES / "airport_counts.csv", index=False)


def main():
    airports(); print("A done")
    dynamic_events(); print("D done")
    R, hexes, cal, meta = dense_focus(); print("dense", R.shape)
    episodes(R, meta, cal); print("B done")
    d = build_long(R, hexes, cal, meta); print("long", len(d))
    distance_decay(d); print("C done")
    nowcast(d); print("E done")


if __name__ == "__main__":
    main()
