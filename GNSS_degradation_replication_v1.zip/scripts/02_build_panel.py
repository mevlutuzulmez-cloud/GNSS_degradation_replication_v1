"""Build the hex-day panel and the hex attribute table.

Outputs
  data/panel.parquet : date, hex(int64), good(int32), bad(int32)
  data/hexes.parquet : hex, lat, lon, country (ISO3, land only), region
  data/daily_global.csv : daily global aggregates

Classification follows GPSJam (https://gpsjam.org/faq):
  pct_bad = 100 * (bad - 1) / (good + bad)  (floored at 0)
  low  : pct_bad < 2   (green)
  med  : 2 <= pct_bad <= 10 (yellow)
  high : pct_bad > 10  (red)
"""
from pathlib import Path

import geopandas as gpd
import h3
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "gpsjam"

# Analysis regions (lon_min, lon_max, lat_min, lat_max). Boxes are deliberately
# coarse; they are reporting units, not airspace (FIR) boundaries.
REGIONS = {
    "Baltic Sea": (9.0, 32.0, 53.0, 61.0),
    "Black Sea": (26.0, 42.0, 40.5, 48.0),
    "Eastern Mediterranean": (28.0, 37.5, 29.0, 37.5),
    "Iraq-Syria-W. Iran": (37.5, 48.5, 29.0, 38.0),
    "Persian Gulf": (47.0, 58.0, 23.0, 30.5),
    "South Asia (Ind-Pak)": (66.0, 80.0, 23.0, 36.0),
    "Myanmar": (92.0, 101.5, 10.0, 28.5),
    "SW United States": (-120.0, -95.0, 25.0, 37.0),
}


def classify_region(lat: np.ndarray, lon: np.ndarray) -> np.ndarray:
    out = np.full(lat.shape, "Rest of world", dtype=object)
    # first match wins; order above is the priority order
    assigned = np.zeros(lat.shape, dtype=bool)
    for name, (x0, x1, y0, y1) in REGIONS.items():
        m = (~assigned) & (lon >= x0) & (lon < x1) & (lat >= y0) & (lat < y1)
        out[m] = name
        assigned |= m
    return out


def main() -> None:
    files = [f for f in sorted(RAW.glob("*.csv")) if f.stat().st_size > 100]
    print("non-empty daily files:", len(files))
    frames = []
    for f in files:
        d = pd.read_csv(f, dtype={"hex": str, "count_good_aircraft": "int32",
                                  "count_bad_aircraft": "int32"})
        d = d.rename(columns={"count_good_aircraft": "good", "count_bad_aircraft": "bad"})
        d["date"] = pd.Timestamp(f.stem)
        frames.append(d)
    p = pd.concat(frames, ignore_index=True)
    p["hex"] = p["hex"].map(h3.str_to_int).astype("int64")
    p = p[["date", "hex", "good", "bad"]]
    p.to_parquet(ROOT / "data" / "panel.parquet", index=False)
    print("panel rows", len(p), "days", p.date.nunique(), "hexes", p.hex.nunique())

    # hex attributes
    hx = pd.DataFrame({"hex": p["hex"].unique()})
    ll = np.array([h3.cell_to_latlng(h3.int_to_str(int(x))) for x in hx.hex])
    hx["lat"], hx["lon"] = ll[:, 0], ll[:, 1]
    hx["region"] = classify_region(hx.lat.values, hx.lon.values)
    world = gpd.read_file(f"zip://{ROOT / 'data' / 'raw' / 'ne' / 'ne_50m_admin_0_countries.zip'}")
    world = world[["ADM0_A3", "NAME", "geometry"]].to_crs(4326)
    pts = gpd.GeoDataFrame(hx, geometry=gpd.points_from_xy(hx.lon, hx.lat), crs=4326)
    j = gpd.sjoin(pts, world, how="left", predicate="within")
    j = j[~j.index.duplicated()]
    hx["iso3"] = j["ADM0_A3"].values
    hx["country"] = j["NAME"].values
    hx.to_parquet(ROOT / "data" / "hexes.parquet", index=False)
    print(hx.region.value_counts())


if __name__ == "__main__":
    main()
