"""Turkey-specific analysis: zones, Ankara cluster sensitivity."""
from pathlib import Path
import numpy as np, pandas as pd, pymannkendall as mk
ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"
p = pd.read_parquet(ROOT / "data" / "derived" / "hexday_focus.parquet")
hx = pd.read_parquet(ROOT / "data" / "hexes.parquet")
t = p[p.iso3 == "TUR"].merge(hx[["hex", "lat", "lon"]], on="hex")
ank = (t.lat.between(39.5, 40.6)) & (t.lon.between(32.0, 33.6))
t["zone"] = np.select([t.lon >= 38, (t.lat >= 40) & (t.lon < 38), (t.lat < 38) & (t.lon < 38)],
                      ["Southeast/East", "North/Black Sea coast", "South/Mediterranean"], "Central/West")
rows = []
for name, s in [("Turkey, all land hexes", t), ("Turkey, excl. Ankara cluster", t[~ank]), ("Ankara cluster only", t[ank])]:
    m = s.assign(month=s.date.dt.to_period("M")).groupby("month").red.mean()
    m = m.iloc[1:-1]
    r = mk.hamed_rao_modification_test(m.values)
    yr = s.assign(y=s.date.dt.year).groupby("y").red.mean()
    rows.append(dict(series=name, n_months=len(m), tau=r.Tau, p=r.p, sen=r.slope, **{f"share_red_{k}": v for k, v in yr.items()}))
pd.DataFrame(rows).to_csv(RES / "turkey_trends.csv", index=False)
z = t[~ank].assign(y=t.date.dt.year).groupby(["zone", "y"]).red.mean().unstack()
z.to_csv(RES / "turkey_zones.csv")
print(pd.DataFrame(rows).round(4).to_string()); print(z.round(3))
