"""Revision analyses requested by the 5-reviewer panel (review/R5_editorial_decision.md).

A  coverage / measurement: hex-month aggregates -> balanced panel, degraded-aircraft share,
   thresholds 5/10/20 %, coverage series, clean negative controls, Russia decomposition, BH trend tests.
B  spatial dependence falsification: lead (t+1) neighbour placebo, contemporaneous control,
   local (H3 res-2 parent x day) fixed effects, two-way clustered SEs.
C  nowcast extensions: climatology baseline, onset-only, PR-AUC, Brier skill, calibration, excl. SW US.
D  events: raw post-pre, traffic pre/post, level-only model, time + space placebos, placebo bands.
E  airport variants: home cell only, fixed 7-cell footprint, >=2 of 7, aircraft-weighted degraded share.
F  episodes: gap-bridging sensitivity, conditional continuation, KM by start year.

Usage: python 11_revision.py [A B C D E F]
"""
import sys
import importlib.util
from pathlib import Path

import h3
import numpy as np
import pandas as pd
import pyarrow.dataset as ds
import statsmodels.formula.api as smf

ROOT = Path(__file__).resolve().parents[1]
DER, RES = ROOT / "data" / "derived", ROOT / "results"
REV = RES / "revision"; REV.mkdir(exist_ok=True)
MAN = pd.read_csv(ROOT / "data" / "raw" / "gpsjam_manifest.csv", parse_dates=["date"])
SUSPECT = set(MAN.loc[MAN.suspect, "date"])

spec = importlib.util.spec_from_file_location("ext", ROOT / "scripts" / "08_extended.py")
ext = importlib.util.module_from_spec(spec); spec.loader.exec_module(ext)


def hex_meta():
    h = pd.read_parquet(ROOT / "data" / "hexes.parquet")
    h["grp"] = h.region
    lev = (h.lon.between(34, 36.7)) & (h.lat.between(31, 34.7))
    weu = (h.lon.between(-10, 8)) & (h.lat.between(36, 51)) & (h.region == "Rest of world")
    jpn = (h.lon.between(129, 146)) & (h.lat.between(30, 46)) & (h.region == "Rest of world")
    h["levant"] = lev
    h["control"] = np.where(weu, "W. Europe (control)", np.where(jpn, "Japan (control)", ""))
    return h


# ================================================================ A
def part_A():
    meta = hex_meta()
    dset = ds.dataset(ROOT / "data" / "panel.parquet")
    parts = []
    for y in range(2022, 2027):
        t = dset.to_table(filter=(ds.field("date") >= pd.Timestamp(f"{y}-01-01")) &
                                 (ds.field("date") < pd.Timestamp(f"{y+1}-01-01"))).to_pandas()
        t = t[~t.date.isin(SUSPECT)]
        t["n"] = t.good + t.bad
        t = t[t.n >= 3]
        adj = (t.bad - 1).clip(lower=0)
        pct = 100 * adj / t.n
        t["r5"], t["r10"], t["r20"] = (pct > 5).astype(np.int16), (pct > 10).astype(np.int16), (pct > 20).astype(np.int16)
        t["n10"] = (t.n >= 10).astype(np.int16)
        t["r10_n10"] = (t.r10 * t.n10).astype(np.int16)
        t["adj"] = adj
        t["n_in_red"] = t.n * t.r10
        t["ym"] = t.date.dt.to_period("M")
        g = t.groupby(["hex", "ym"]).agg(obs=("n", "size"), r5=("r5", "sum"), r10=("r10", "sum"), r20=("r20", "sum"),
                                         obs10=("n10", "sum"), r10_n10=("r10_n10", "sum"),
                                         n=("n", "sum"), adj=("adj", "sum"), bad=("bad", "sum"),
                                         n_in_red=("n_in_red", "sum")).reset_index()
        parts.append(g); print("A year", y, len(g), flush=True)
        del t
    hm = pd.concat(parts)
    hm["year"] = hm.ym.dt.year
    hm.to_parquet(DER / "hexmonth.parquet")
    summarize_A(hm, meta)


def summarize_A(hm=None, meta=None):
    from pymannkendall import hamed_rao_modification_test as mk
    from statsmodels.stats.multitest import multipletests
    if hm is None:
        hm = pd.read_parquet(DER / "hexmonth.parquet"); meta = hex_meta()
    for c in ["obs", "r5", "r10", "r20", "obs10", "r10_n10"]:
        hm[c] = hm[c].astype(np.int64)
    hm = hm.merge(meta[["hex", "region", "iso3", "levant", "control"]], on="hex", how="left")
    # days observed per year per hex -> balanced panel: >=30% of days observed in every year (2022 partial)
    hy = hm.groupby(["hex", "year"]).obs.sum().unstack(fill_value=0)
    ndays = {2022: 320, 2023: 365, 2024: 366, 2025: 365, 2026: 317}
    frac = hy / pd.Series(ndays)
    balanced = frac.index[(frac >= 0.3).all(axis=1)]
    hm["balanced"] = hm.hex.isin(balanced)
    print("balanced hexes", len(balanced), "of", len(hy))

    def groups(df):
        out = {"Global": df}
        for r, g in df.groupby("region"):
            out[r] = g
        out["Levant core"] = df[df.levant == True]
        out["Türkiye (land)"] = df[df.iso3 == "TUR"]
        for c, g in df[df.control != ""].groupby("control"):
            out[c] = g
        return out

    def metrics(g):
        s = g[["obs", "r5", "r10", "r20", "obs10", "r10_n10", "n", "adj", "bad", "n_in_red"]].sum()
        return pd.Series(dict(share5=100 * s.r5 / s.obs, share10=100 * s.r10 / s.obs, share20=100 * s.r20 / s.obs,
                              share10_n10=100 * s.r10_n10 / max(s.obs10, 1),
                              degraded=100 * s.adj / s.n, degraded_raw=100 * s.bad / s.n,
                              ac_in_red=100 * s.n_in_red / s.n, hexdays=s.obs, ac_per_hexday=s.n / s.obs))
    rows = []
    for sample, df in [("all", hm), ("balanced", hm[hm.balanced])]:
        for name, g in groups(df).items():
            for y, gy in g.groupby("year"):
                rows.append(dict(sample=sample, group=name, year=y, hexes=gy.hex.nunique(), **metrics(gy)))
    ann = pd.DataFrame(rows)
    ann.to_csv(REV / "A_annual_measures.csv", index=False)

    # monthly series + MK tests with BH, for balanced red share and degraded share
    mrows = []
    for sample, df in [("all", hm), ("balanced", hm[hm.balanced])]:
        for name, g in groups(df).items():
            m = g.groupby("ym")[["obs", "r10", "adj", "n"]].sum()
            m = m[m.obs >= 30]
            for var, ser in [("share10", 100 * m.r10 / m.obs), ("degraded", 100 * m.adj / m.n)]:
                if len(ser) < 24 or ser.std() == 0:
                    continue
                r = mk(ser.values)
                mrows.append(dict(sample=sample, group=name, var=var, months=len(ser), tau=r.Tau, p=r.p,
                                  sen_pp_yr=12 * r.slope, first12=ser.iloc[:12].mean(), last12=ser.iloc[-12:].mean()))
    mt = pd.DataFrame(mrows)
    mt["p_bh"] = np.nan
    for (s, v), g in mt.groupby(["sample", "var"]):
        idx = g.index[g.group != "Global"]
        mt.loc[idx, "p_bh"] = multipletests(mt.loc[idx, "p"], method="fdr_bh")[1]
    mt.to_csv(REV / "A_trend_tests.csv", index=False)

    # typology under thresholds and balanced panel; Russia decomposition
    hyr = hm.groupby(["hex", "year"])[["obs", "r5", "r10", "r20"]].sum().reset_index()
    hyr = hyr[hyr.obs >= 30].merge(meta[["hex", "iso3", "region"]], on="hex")
    hyr["balanced"] = hyr.hex.isin(balanced)
    trows = []
    for thr in ("r5", "r10", "r20"):
        f = hyr[thr] / hyr.obs
        cls = np.select([f > 0.5, f > 0.1, f > 0], ["chronic", "recurrent", "sporadic"], "none")
        for samp, mask in [("all", np.ones(len(hyr), bool)), ("balanced", hyr.balanced.values)]:
            for excl, m2 in [("incl. Russia", np.ones(len(hyr), bool)), ("excl. Russia", (hyr.iso3 != "RUS").values)]:
                sub = pd.DataFrame({"year": hyr.year[mask & m2], "cls": cls[mask & m2]})
                c = sub.groupby(["year", "cls"]).size().unstack(fill_value=0)
                for y, r in c.iterrows():
                    trows.append(dict(threshold=thr, sample=samp, russia=excl, year=y,
                                      chronic=r.get("chronic", 0), recurrent=r.get("recurrent", 0),
                                      rec_chr=r.get("chronic", 0) + r.get("recurrent", 0), eligible=r.sum()))
    pd.DataFrame(trows).to_csv(REV / "A_typology_variants.csv", index=False)
    f = hyr.r10 / hyr.obs
    hyr["rc"] = f > 0.1
    rus = hyr[hyr.rc].groupby(["year", hyr.iso3.eq("RUS").map({True: "Russia", False: "Other"})]).size().unstack()
    rus.to_csv(REV / "A_russia_rc.csv")
    print(ann[(ann["sample"] == "balanced") & (ann.group == "Global")])


# ================================================================ B
def part_B():
    import pyfixest as pf
    import scipy.sparse as sp
    R, hexes, cal, meta = ext.dense_focus()
    obs = (~np.isnan(R)).astype(np.float32); red0 = np.nan_to_num(R)
    A = ext.ring_matrix(hexes, 1)
    with np.errstate(invalid="ignore", divide="ignore"):
        c = A @ obs
        S1 = np.where(c >= 2, (A @ red0) / c, np.nan).astype(np.float32)
    ii, tt = np.where(~np.isnan(R[:, 1:-1]) & ~np.isnan(R[:, :-2]))
    tt = tt + 1
    d = pd.DataFrame({"h": ii, "t": tt, "red100": 100 * R[ii, tt], "prev": R[ii, tt - 1],
                      "s_lag": S1[ii, tt - 1], "s_now": S1[ii, tt], "s_lead": S1[ii, tt + 1]})
    d["date"] = cal[d.t.values]
    d["region"] = meta.region.values[d.h.values]
    par = np.array([h3.str_to_int(h3.cell_to_parent(h3.int_to_str(int(x)), 2)) for x in hexes])
    d["par"] = par[d.h.values]
    d["reg_date"] = d.region + "_" + d.t.astype(str)
    d["par_date"] = d.par.astype(str) + "_" + d.t.astype(str)
    on = d[(d.prev == 0)].dropna(subset=["s_lag"])
    rows = []
    specs = [
        ("M1 baseline (lag)", "red100 ~ s_lag | h + reg_date", on, {"CRV1": "h"}),
        ("M1 two-way clustered", "red100 ~ s_lag | h + reg_date", on, {"CRV1": "h+reg_date"}),
        ("M2 lag + lead (placebo)", "red100 ~ s_lag + s_lead | h + reg_date", on.dropna(subset=["s_lead"]), {"CRV1": "h+reg_date"}),
        ("M3 lag + contemporaneous", "red100 ~ s_lag + s_now | h + reg_date", on.dropna(subset=["s_now"]), {"CRV1": "h+reg_date"}),
        ("M4 lag, local FE (res-2 parent x day)", "red100 ~ s_lag | h + par_date", on, {"CRV1": "h+par_date"}),
        ("M5 lag + lead + now, local FE", "red100 ~ s_lag + s_lead + s_now | h + par_date",
         on.dropna(subset=["s_lead", "s_now"]), {"CRV1": "h+par_date"}),
    ]
    for name, fml, data, vc in specs:
        m = pf.feols(fml, data=data, vcov=vc)
        t = m.tidy().reset_index()
        t["model"] = name; t["nobs"] = m._N
        rows.append(t); print(name, flush=True); print(t[["Coefficient", "Estimate", "Std. Error"]])
    pd.concat(rows).to_csv(REV / "B_spatial_falsification.csv", index=False)


# ================================================================ C
def part_C():
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
    R, hexes, cal, meta = ext.dense_focus()
    d = ext.build_long(R, hexes, cal, meta)
    obs = (~np.isnan(R)).astype(np.float32)
    cs_red = np.cumsum(np.nan_to_num(R), axis=1); cs_obs = np.cumsum(obs, axis=1)
    def lagwin(cs, w):
        out = np.full(cs.shape, np.nan, dtype=np.float32)
        out[:, w + 1:] = cs[:, w:-1] - cs[:, :-w - 1]
        return out
    with np.errstate(invalid="ignore", divide="ignore"):
        f28 = lagwin(cs_red, 28) / lagwin(cs_obs, 28)
        f365 = lagwin(cs_red, 365) / lagwin(cs_obs, 365)
    d["freq28"] = f28[d.h.values, d.t.values]
    d["freq365"] = f365[d.h.values, d.t.values]
    x = d[d.c1 >= 1].copy()
    for c in ["s1", "s2", "s3", "freq7", "freq28", "freq365"]:
        x[c + "_na"] = x[c].isna().astype(float); x[c] = x[c].fillna(0)
    train = x[x.date < "2026-01-01"]; test = x[x.date >= "2026-01-01"].copy()
    tr = train.sample(n=min(3_000_000, len(train)), random_state=1)
    models = {"Climatology: 28-day frequency": ["freq28", "freq28_na"],
              "Climatology: 365-day frequency": ["freq365", "freq365_na"],
              "Persistence only": ["prev"],
              "Own history": ["prev", "freq7", "freq7_na"],
              "Own history + 28-day": ["prev", "freq7", "freq7_na", "freq28", "freq28_na"],
              "Full": ["prev", "freq7", "freq7_na", "freq28", "freq28_na", "s1", "s2", "s3", "s2_na", "s3_na"]}
    base_bs = test.red.mean() * (1 - test.red.mean())
    rows, cal_rows = [], []
    for name, fs in models.items():
        lr = LogisticRegression(max_iter=1000).fit(tr[fs], tr.red)
        test["p"] = lr.predict_proba(test[fs])[:, 1]
        for subset, g in [("All focal", test), ("All focal excl. SW US", test[test.region != "SW United States"]),
                          ("Onsets (not red at t−1)", test[test.prev == 0]),
                          ("Cessations (red at t−1)", test[test.prev == 1])]:
            bs = brier_score_loss(g.red, g.p); bref = g.red.mean() * (1 - g.red.mean())
            lp = np.log(np.clip(g.p, 1e-6, 1 - 1e-6) / (1 - np.clip(g.p, 1e-6, 1 - 1e-6)))
            cm = LogisticRegression(C=1e6, max_iter=500).fit(lp.values.reshape(-1, 1), g.red)
            # operating point: threshold maximising F1 is tuned on train? use fixed 0.5 and 0.2
            ops = {}
            for th in (0.2, 0.5):
                pr = g.p >= th
                tp = (pr & (g.red == 1)).sum()
                ops[f"precision@{th}"] = tp / max(pr.sum(), 1); ops[f"recall@{th}"] = tp / max(g.red.sum(), 1)
            rows.append(dict(model=name, subset=subset, n=len(g), base_rate=g.red.mean(),
                             auc=roc_auc_score(g.red, g.p), pr_auc=average_precision_score(g.red, g.p),
                             brier=bs, bss=1 - bs / bref, cal_slope=cm.coef_[0][0], cal_int=cm.intercept_[0], **ops))
        if name == "Full":
            test["bin"] = pd.cut(test.p, np.r_[0, 0.01, 0.02, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0001], right=False)
            cb = test.groupby("bin", observed=True).agg(p_mean=("p", "mean"), obs_rate=("red", "mean"), n=("red", "size")).reset_index()
            cb["bin"] = cb.bin.astype(str); cb.to_csv(REV / "C_calibration_full.csv", index=False)
            # onset-only by region
            for reg, g in test[test.prev == 0].groupby("region"):
                if g.red.sum() >= 30:
                    rows.append(dict(model=name, subset=f"Onsets: {reg}", n=len(g), base_rate=g.red.mean(),
                                     auc=roc_auc_score(g.red, g.p), pr_auc=average_precision_score(g.red, g.p)))
        print(name, flush=True)
    excl = 1 - len(x[x.date >= "2026-01-01"]) / max(1, ((~np.isnan(R[:, cal >= "2026-01-01"])).sum()))
    out = pd.DataFrame(rows); out["excluded_share_2026"] = excl
    out.to_csv(REV / "C_nowcast_extended.csv", index=False)
    print(out[out.subset.isin(["All focal", "Onsets (not red at t−1)"])][["model", "subset", "auc", "pr_auc", "bss"]])


# ================================================================ D
EVENTS = [("Israel–Hamas war", "2023-10-07", ["Levant core", "Eastern Mediterranean"]),
          ("India–Pakistan strikes", "2025-05-07", ["South Asia (Ind-Pak)"]),
          ("Israel–Iran war", "2025-06-13", ["Persian Gulf", "Iraq-Syria-W. Iran", "Levant core"]),
          ("US–Israel strikes on Iran", "2026-02-28", ["Persian Gulf", "Iraq-Syria-W. Iran", "Eastern Mediterranean", "Levant core", "Turkey (land)"])]
UNTREATED = ["Baltic Sea", "Myanmar", "SW United States", "Rest of world", "Black Sea"]
WIN = 90


def raw_diff(ser, t0, var="share_red", win=WIN):
    pre = ser[(ser.date >= t0 - pd.Timedelta(days=win)) & (ser.date < t0)]
    post = ser[(ser.date >= t0) & (ser.date < t0 + pd.Timedelta(days=win))]
    if len(pre) < win * 0.6 or len(post) < win * 0.6:
        return None
    return dict(pre=100 * pre[var].mean(), post=100 * post[var].mean(), diff=100 * (post[var].mean() - pre[var].mean()),
                hex_pre=pre.hexes.mean(), hex_post=post.hexes.mean(), ac_pre=pre.aircraft.mean(), ac_post=post.aircraft.mean())


def part_D():
    d = pd.read_csv(DER / "daily_region.csv", parse_dates=["date"])
    d = d[~d.suspect.fillna(False)]
    ev_dates = [pd.Timestamp(e[1]) for e in EVENTS]
    rows, bands = [], []
    for label, date, regs in EVENTS:
        t0 = pd.Timestamp(date)
        for reg in regs:
            ser = d[d.region == reg].sort_values("date")
            r = raw_diff(ser, t0)
            if r is None:
                continue
            # level-only model (no pre-trend) with HAC, and window sensitivity
            alt = {}
            for w in (30, 60, 90, 120):
                rw = raw_diff(ser, t0, win=w)
                alt[f"diff_w{w}"] = rw["diff"] if rw else np.nan
            # time placebos: daily pseudo-dates whose +-90 window does not overlap any listed event window
            cand = pd.date_range(ser.date.min() + pd.Timedelta(days=WIN), t0 - pd.Timedelta(days=WIN), freq="D")
            cand = [c for c in cand if all(abs((c - e).days) > 2 * WIN for e in ev_dates)]
            pl = [raw_diff(ser, c) for c in cand]
            pl = np.array([p["diff"] for p in pl if p is not None])
            p_time = (np.sum(np.abs(pl) >= abs(r["diff"])) + 1) / (len(pl) + 1) if len(pl) else np.nan
            # space placebos: same date in untreated regions
            sp_ = [raw_diff(d[d.region == u].sort_values("date"), t0) for u in UNTREATED]
            sp_ = [s["diff"] for s in sp_ if s]
            rows.append(dict(event=label, date=date, region=reg, **r, **alt, n_time_placebo=len(pl),
                             p_time=p_time, placebo_abs_p95=np.percentile(np.abs(pl), 95) if len(pl) else np.nan,
                             space_placebo_max_abs=np.max(np.abs(sp_)) if sp_ else np.nan,
                             space_placebos=";".join(f"{u}:{v:.1f}" for u, v in zip(UNTREATED, sp_))))
            # weekly dynamic profile with placebo null band
            def profile(c0):
                s = ser[(ser.date >= c0 - pd.Timedelta(days=84)) & (ser.date < c0 + pd.Timedelta(days=84))].copy()
                if len(s) < 120:
                    return None
                s["w"] = ((s.date - c0).dt.days // 7)
                wm = 100 * s.groupby("w").share_red.mean()
                return wm - wm[wm.index < 0].mean()
            real = profile(t0)
            pls = [profile(c) for c in cand[::7]]
            pls = pd.concat([p for p in pls if p is not None], axis=1) if any(p is not None for p in pls) else None
            for w, v in real.items():
                lo = hi = np.nan
                if pls is not None and w in pls.index:
                    lo, hi = np.nanpercentile(pls.loc[w], [2.5, 97.5])
                bands.append(dict(event=date, region=reg, week=w, coef=v, null_lo=lo, null_hi=hi,
                                  n_placebo=0 if pls is None else pls.shape[1]))
    pd.DataFrame(rows).to_csv(REV / "D_events_raw.csv", index=False)
    pd.DataFrame(bands).to_csv(REV / "D_dynamic_placebo_bands.csv", index=False)
    print(pd.DataFrame(rows)[["event", "region", "pre", "post", "diff", "p_time", "n_time_placebo", "hex_pre", "hex_post", "ac_pre", "ac_post", "space_placebo_max_abs"]].round(2).to_string())


# ================================================================ E
def part_E():
    ap = pd.read_csv(ROOT / "data" / "raw" / "ourairports_airports.csv", low_memory=False)
    ap = ap[ap.type.isin(["large_airport", "medium_airport"]) & (ap.scheduled_service == "yes")].copy()
    ap["cell"] = [h3.str_to_int(h3.latlng_to_cell(a, b, 4)) for a, b in zip(ap.latitude_deg, ap.longitude_deg)]
    foot = [(r.ident, h3.str_to_int(c), int(h3.str_to_int(c) == r.cell)) for r in ap.itertuples()
            for c in h3.grid_disk(h3.int_to_str(int(r.cell)), 1)]
    foot = pd.DataFrame(foot, columns=["ident", "hex", "home"])
    p = pd.read_parquet(ROOT / "data" / "panel.parquet", filters=[("hex", "in", list(set(foot.hex)))])
    p = p[~p.date.isin(SUSPECT)]
    p["n"] = p.good + p.bad; p = p[p.n >= 3]
    p["adj"] = (p.bad - 1).clip(lower=0)
    p["red"] = (100 * p.adj / p.n > 10).astype(int)
    x = foot.merge(p[["date", "hex", "red", "n", "adj"]], on="hex")
    x["red_home"] = x.red * x.home; x["obs_home"] = x.home
    ad = x.groupby(["ident", "date"]).agg(k=("red", "size"), nred=("red", "sum"), red_home=("red_home", "max"),
                                         obs_home=("obs_home", "max"), n=("n", "sum"), adj=("adj", "sum")).reset_index()
    ad["year"] = ad.date.dt.year
    ad["any7"] = (ad.nred >= 1).astype(int); ad["two7"] = (ad.nred >= 2).astype(int)
    ad["full7"] = ad.k == 7
    rows = []
    for (ident, y), g in ad.groupby(["ident", "year"]):
        if len(g) < 30:
            continue
        gh = g[g.obs_home == 1]; gf = g[g.full7]
        rows.append(dict(ident=ident, year=y, days=len(g), mean_k=g.k.mean(), share_any7=g.any7.mean(),
                         share_two7=g.two7.mean(),
                         share_home=gh.red_home.mean() if len(gh) >= 30 else np.nan,
                         share_full7=gf.any7.mean() if len(gf) >= 30 else np.nan,
                         degraded_share=100 * g.adj.sum() / g.n.sum()))
    ay = pd.DataFrame(rows).merge(ap[["ident", "name", "type", "iso_country", "iata_code"]], on="ident")
    ay.to_csv(REV / "E_airport_variants.csv", index=False)
    # counts per year by variant; fixed set = airports with >=30 days in every year
    fixed = ay.groupby("ident").year.nunique(); fixed = fixed.index[fixed == 5]
    crows = []
    for samp, df in [("all", ay), ("fixed set", ay[ay.ident.isin(fixed)])]:
        for y, g in df.groupby("year"):
            crows.append(dict(sample=samp, year=y, airports=len(g), mean_k=g.mean_k.mean(),
                              any7_ge10=(g.share_any7 >= .1).sum(), any7_ge50=(g.share_any7 >= .5).sum(),
                              two7_ge10=(g.share_two7 >= .1).sum(), home_ge10=(g.share_home >= .1).sum(),
                              home_n=g.share_home.notna().sum(), full7_ge10=(g.share_full7 >= .1).sum(),
                              full7_n=g.share_full7.notna().sum(), degr_ge5=(g.degraded_share >= 5).sum()))
    c = pd.DataFrame(crows); c.to_csv(REV / "E_airport_counts_variants.csv", index=False)
    print(c.to_string())


# ================================================================ F
def part_F():
    R, hexes, cal, meta = ext.dense_focus()
    Rb = R.copy()
    gap = np.isnan(R[:, 1:-1]) & (R[:, :-2] == 1) & (R[:, 2:] == 1)
    Rb[:, 1:-1][gap] = 1
    rows = []
    for name, M in [("baseline", R), ("bridged 1-day gaps", Rb)]:
        recs = []
        for i in range(M.shape[0]):
            r = M[i]; t = 0; nT = len(r)
            while t < nT:
                if r[t] == 1 and (t == 0 or r[t - 1] != 1):
                    st = t
                    while t + 1 < nT and r[t + 1] == 1:
                        t += 1
                    left_trunc = 1 if (st == 0 or np.isnan(r[st - 1])) else 0
                    ev = 1 if (t + 1 < nT and r[t + 1] == 0) else 0
                    recs.append((i, st, t - st + 1, ev, left_trunc))
                t += 1
        e = pd.DataFrame(recs, columns=["h", "start", "dur", "event", "ltrunc"])
        e["region"] = meta.region.values[e.h.values]; e["year"] = cal[e.start.values].year
        for sub, g in [("all", e), ("clean start (no left truncation)", e[e.ltrunc == 0])]:
            for grp, gg in [("All focal", g)] + [(f"start {y}", gy) for y, gy in g.groupby("year")]:
                km = ext.kaplan_meier(gg.dur.values, gg.event.values)
                S = lambda d: km.loc[km.t <= d, "S"].min() if (km.t <= d).any() else 1.0
                rows.append(dict(variant=name, subset=sub, group=grp, episodes=len(gg), median=km.loc[km.S <= .5, "t"].min(),
                                 S7=S(7), S14=S(14), S30=S(30), P14_given7=S(14) / S(7), P30_given7=S(30) / S(7)))
    out = pd.DataFrame(rows); out.to_csv(REV / "F_episode_sensitivity.csv", index=False)
    print(out.round(3).to_string())


if __name__ == "__main__":
    todo = sys.argv[1:] or list("ABCDEF")
    for p in todo:
        (globals()["part_" + p] if p != "As" else summarize_A)() if p != "D2" else None
        print("done", p, flush=True)


# ================================================================ D2: fixed-composition event check
def part_D2():
    f = pd.read_parquet(DER / "hexday_focus.parquet")
    f = f[~f.date.isin(SUSPECT)]
    meta = hex_meta().set_index("hex")
    f["levant"] = meta.levant.reindex(f.hex).values
    rows = []
    for label, date, regs in EVENTS:
        t0 = pd.Timestamp(date)
        w = f[(f.date >= t0 - pd.Timedelta(days=WIN)) & (f.date < t0 + pd.Timedelta(days=WIN))].copy()
        w["post"] = w.date >= t0
        for reg in regs:
            if reg == "Levant core":
                s = w[w.levant == True]
            elif reg == "Turkey (land)":
                s = w[w.iso3 == "TUR"]
            else:
                s = w[w.region == reg]
            for nmin in (3, 10):
                s2 = s[s.n >= nmin]
                cov = s2.groupby(["hex", "post"]).size().unstack(fill_value=0)
                keep = cov.index[(cov.get(False, 0) >= 0.5 * WIN) & (cov.get(True, 0) >= 0.5 * WIN)]
                s3 = s2[s2.hex.isin(keep)]
                if len(keep) == 0:
                    continue
                m = s3.groupby("post").red.mean() * 100
                rows.append(dict(event=label, region=reg, n_min=nmin, fixed_hexes=len(keep),
                                 pre=m.get(False), post=m.get(True), diff=m.get(True) - m.get(False),
                                 ac_per_hex_pre=s3[~s3.post].n.mean(), ac_per_hex_post=s3[s3.post].n.mean()))
    out = pd.DataFrame(rows); out.to_csv(REV / "D2_events_fixed_hexes.csv", index=False)
    print(out.round(2).to_string())


if __name__ == "__main__" and sys.argv[1:] == ["D2"]:
    part_D2()
