"""Markdown tables for the revised manuscript (from results/revision/*.csv)."""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
REV = ROOT / "results" / "revision"
OUT = ROOT / "manuscript" / "tables_revision.md"
REN = {"Iraq-Syria-W. Iran": "Iraq–Syria–W. Iran", "South Asia (Ind-Pak)": "South Asia (India–Pakistan)",
       "Turkey (land)": "Türkiye (land)"}
ORDER = ["Global", "Baltic Sea", "Black Sea", "Eastern Mediterranean", "Levant core", "Iraq-Syria-W. Iran",
         "Persian Gulf", "South Asia (Ind-Pak)", "Myanmar", "Türkiye (land)", "SW United States", "Rest of world",
         "W. Europe (control)", "Japan (control)"]


def md(df):
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(str(v) for v in r.values) + " |")
    return "\n".join(lines)


def p(v):
    return "<0.001" if v < 0.001 else f"{v:.3f}"


def f(v, d=1):
    if pd.isna(v):
        return "–"
    s = f"{v:,.{d}f}"
    return s.replace("-", "−")


out = []
# ---- Table 2: degraded-aircraft share by region-year
a = pd.read_csv(REV / "A_annual_measures.csv")
x = a[a["sample"] == "all"].pivot(index="group", columns="year", values="degraded").reindex(ORDER)
t = pd.DataFrame({"Region": [REN.get(i, i) for i in x.index]})
for y in x.columns:
    t[str(y)] = [f(v, 2) for v in x[y]]
out.append("## T2 degraded share\n\n" + md(t))

# ---- Table 3: trend robustness (balanced panel and degraded share, BH)
tt = pd.read_csv(REV / "A_trend_tests.csv")
rows = []
for g in ORDER:
    r = {"Region": REN.get(g, g)}
    for samp, var, lab in [("balanced", "share10", "Balanced panel: red share"), ("all", "degraded", "Degraded-aircraft share")]:
        s = tt[(tt["sample"] == samp) & (tt.group == g) & (tt["var"] == var)]
        if len(s) == 0:
            r[lab + " τ"] = "–"; r[lab + " p (BH)"] = "–"; continue
        s = s.iloc[0]
        r[f"{lab}: first→last 12 mo. (%)"] = f"{f(s.first12, 2)} → {f(s.last12, 2)}"
        r[f"{lab}: τ"] = f"{s.tau:.2f}".replace("-", "−")
        r[f"{lab}: p (BH)"] = p(s.p if g == "Global" else s.p_bh)
    rows.append(r)
out.append("## T3 trend robustness\n\n" + md(pd.DataFrame(rows)))

# ---- Table 4b: typology variants (recurrent + chronic counts)
ty = pd.read_csv(REV / "A_typology_variants.csv")
var = [("r10", "all", "incl. Russia", "Main (10%, all cells)"), ("r10", "balanced", "incl. Russia", "Balanced panel"),
       ("r10", "all", "excl. Russia", "Excluding Russia"), ("r5", "all", "incl. Russia", "5% threshold"),
       ("r20", "all", "incl. Russia", "20% threshold"), ("r20", "balanced", "excl. Russia", "20%, balanced, excl. Russia")]
rows = []
for thr, samp, rus, lab in var:
    s = ty[(ty.threshold == thr) & (ty["sample"] == samp) & (ty.russia == rus)].set_index("year")
    rows.append({"Variant": lab, **{str(y): f"{int(s.loc[y, 'rec_chr']):,} ({int(s.loc[y, 'chronic']):,})" for y in s.index}})
out.append("## T4b typology variants\n\n" + md(pd.DataFrame(rows)))

# ---- Table 6: events
d = pd.read_csv(REV / "D_events_raw.csv")
d2 = pd.read_csv(REV / "D2_events_fixed_hexes.csv")
its = pd.read_csv(ROOT / "results" / "event_studies.csv")
its = its[its["var"] == "share_red"]
rows = []
for _, r in d.iterrows():
    fx3 = d2[(d2.event == r.event) & (d2.region == r.region) & (d2.n_min == 3)]
    fx10 = d2[(d2.event == r.event) & (d2.region == r.region) & (d2.n_min == 10)]
    it = its[(its.date == r.date) & (its.region == r.region)]
    ws = [r.diff_w30, r.diff_w60, r.diff_w90, r.diff_w120]
    rows.append({"Event (date)": f"{r.event} ({r.date})", "Region": REN.get(r.region, r.region),
                 "Pre → post mean (%)": f"{f(r.pre)} → {f(r.post)}",
                 "Raw change (pp)": ("+" if r["diff"] > 0 else "") + f(r["diff"]),
                 "Range, ±30 to ±120 d": f"{f(min(ws))} to {f(max(ws))}",
                 "p (time placebo)": p(r.p_time) if r.p_time >= 0.002 else "0.002*",
                 "Fixed cells, n≥3 / n≥10 (pp)": (f"{f(fx3['diff'].iloc[0])} / {f(fx10['diff'].iloc[0])}" if len(fx3) and len(fx10) else "–"),
                 "Aircraft-hex obs./day, change (%)": f(100 * (r.ac_post / r.ac_pre - 1), 0),
                 "ITS level shift (pp)": f(it.level.iloc[0]) if len(it) else "–"})
out.append("## T6 events\n\n" + md(pd.DataFrame(rows)))

# ---- Table 8: nowcast
c = pd.read_csv(REV / "C_nowcast_extended.csv")
models = [("Climatology: 365-day frequency", "Static map: own red-day share, previous 365 days"),
          ("Climatology: 28-day frequency", "Static map: own red-day share, previous 28 days"),
          ("Persistence only", "Own state at t−1"),
          ("Own history", "Own state; 7-day own frequency"),
          ("Own history + 28-day", "Own state; 7- and 28-day frequencies"),
          ("Full", "Own history + 28-day + red shares of rings 1–3")]
rows = []
for m, lab in models:
    a_ = c[(c.model == m) & (c.subset == "All focal")].iloc[0]
    o_ = c[(c.model == m) & (c.subset == "Onsets (not red at t−1)")].iloc[0]
    x_ = c[(c.model == m) & (c.subset == "All focal excl. SW US")].iloc[0]
    rows.append({"Model": lab, "AUC": f"{a_.auc:.3f}", "PR-AUC": f"{a_.pr_auc:.3f}", "Brier skill": f"{a_.bss:.2f}",
                 "AUC excl. SW US": f"{x_.auc:.3f}", "Onsets: AUC": f"{o_.auc:.3f}", "Onsets: PR-AUC": f"{o_.pr_auc:.3f}",
                 "Precision / recall at 0.5": f"{a_['precision@0.5']:.2f} / {a_['recall@0.5']:.2f}"})
out.append("## T8 nowcast\n\n" + md(pd.DataFrame(rows)))

# ---- Appendix: airport variants
e = pd.read_csv(REV / "E_airport_counts_variants.csv")
rows = []
for samp in ("all", "fixed set"):
    for _, r in e[e["sample"] == samp].iterrows():
        rows.append({"Airport set": "All observed" if samp == "all" else "Fixed (2,170 airports)", "Year": int(r.year),
                     "Airports": f"{int(r.airports):,}", "Mean observed cells (of 7)": f"{r.mean_k:.1f}",
                     "Any of 7 cells, ≥10% days": int(r.any7_ge10), "Any of 7, ≥50% days": int(r.any7_ge50),
                     "≥2 of 7 cells, ≥10%": int(r.two7_ge10), "Home cell only, ≥10%": int(r.home_ge10),
                     "All 7 observed, ≥10%": int(r.full7_ge10), "Degraded share ≥5%": int(r.degr_ge5)})
out.append("## TA3 airport variants\n\n" + md(pd.DataFrame(rows)))

# ---- KM sensitivity
k = pd.read_csv(REV / "F_episode_sensitivity.csv")
rows = []
for (v_, s_), g in k.groupby(["variant", "subset"], sort=False):
    for _, r in g.iterrows():
        rows.append({"Variant": f"{v_}; {s_}", "Group": r.group, "Episodes": f"{int(r.episodes):,}", "Median (days)": int(r["median"]),
                     "S(7)": f"{r.S7:.3f}", "S(30)": f"{r.S30:.3f}", "P(>14 | >7)": f"{r.P14_given7:.2f}"})
out.append("## TA4 KM sensitivity\n\n" + md(pd.DataFrame(rows)))

OUT.write_text("\n\n".join(out), encoding="utf-8")
print("written", OUT)
