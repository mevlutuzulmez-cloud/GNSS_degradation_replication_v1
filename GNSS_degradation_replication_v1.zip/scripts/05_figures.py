"""Publication figures (PNG 300 dpi + PDF)."""
from pathlib import Path

import geopandas as gpd
import h3
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.collections import PolyCollection

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)
RES = ROOT / "results"
DER = ROOT / "data" / "derived"

CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
mpl.rcParams.update({
    "font.family": "Times New Roman", "font.size": 9.5, "mathtext.fontset": "stix", "axes.edgecolor": INK2, "axes.labelcolor": INK,
    "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
    "legend.frameon": False, "lines.linewidth": 1.6, "savefig.dpi": 300, "savefig.bbox": "tight",
})
EVENTS = {"2023-10-07": "Oct 2023\nIsrael–Hamas", "2025-06-13": "Jun 2025\nIsrael–Iran",
          "2026-02-28": "Feb 2026\nUS/Israel–Iran"}
REG_ORDER = ["Baltic Sea", "Black Sea", "Eastern Mediterranean", "Levant core", "Iraq-Syria-W. Iran",
             "Persian Gulf", "South Asia (Ind-Pak)", "Myanmar", "Turkey (land)", "SW United States",
             "Rest of world"]


def save(fig, name):
    fig.savefig(FIG / f"{name}.png")
    fig.savefig(FIG / f"{name}.pdf")
    plt.close(fig)


def fig1_global(m):
    g = m[m.region == "Global"].sort_values("month")
    fig, axes = plt.subplots(2, 1, figsize=(7.0, 4.6), sharex=True)
    series = [("share_red", 100, "High-interference hexes\n(% of observed hexes)"),
              ("area_red_km2", 1e-6, "Daily red (degraded) area\n(million km²)")]
    for ax, (v, k, lab) in zip(axes, series):
        ax.plot(g.month, g[v] * k, color=CAT[0])
        ax.set_ylabel(lab)
        ax.set_ylim(bottom=0)
        for dte, txt in EVENTS.items():
            ax.axvline(pd.Timestamp(dte), color=INK2, lw=0.7, ls=":")
    for dte, txt in EVENTS.items():
        axes[0].text(pd.Timestamp(dte) - pd.Timedelta(days=12), 0.06, txt, fontsize=6.5, color=INK2,
                     ha="right", va="bottom")
    axes[1].set_xlabel("Month (UTC)")
    save(fig, "fig1_global_trend")


def fig2_heatmap(m):
    regs = [r for r in REG_ORDER if r in m.region.unique()]
    pv = m[m.region.isin(regs)].pivot(index="region", columns="month", values="share_red").reindex(regs) * 100
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    im = ax.imshow(pv.values, aspect="auto", cmap="Reds", vmin=0, vmax=80, interpolation="nearest")
    ax.set_yticks(range(len(regs)), regs)
    cols = pv.columns
    ticks = [i for i, c in enumerate(cols) if c.month in (1, 7)]
    ax.set_xticks(ticks, [cols[i].strftime("%b %Y") for i in ticks], rotation=0, fontsize=7)
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.01)
    cb.set_label("Red (degraded) hexes (% of observed)")
    cb.outline.set_visible(False)
    save(fig, "fig2_region_heatmap")


def hex_polys(hexes):
    polys = []
    for hx in hexes:
        b = h3.cell_to_boundary(h3.int_to_str(int(hx)))
        polys.append([(lon, lat) for lat, lon in b])
    return polys


def fig3_maps():
    hy = pd.read_csv(DER / "hex_year_class.csv")
    world = gpd.read_file(f"zip://{ROOT / 'data' / 'raw' / 'ne' / 'ne_50m_admin_0_countries.zip'}")
    ext = (-12, 102, 8, 66)
    years = [2022, 2024, 2026]
    fig, axes = plt.subplots(3, 1, figsize=(7.2, 9.6))
    cmap = mpl.colormaps["Reds"]
    norm = mpl.colors.Normalize(0, 1)
    for ax, y in zip(axes, years):
        world.boundary.plot(ax=ax, color="#b9b8b2", lw=0.3)
        s = hy[(hy.year == y) & (hy.freq_red > 0) & hy.lon.between(ext[0] - 2, ext[1] + 2) & hy.lat.between(ext[2] - 2, ext[3] + 2)]
        pc = PolyCollection(hex_polys(s.hex), array=s.freq_red.values, cmap=cmap, norm=norm, edgecolors="none")
        ax.add_collection(pc)
        ax.set_xlim(ext[0], ext[1]); ax.set_ylim(ext[2], ext[3])
        ax.set_aspect(1.25); ax.grid(False)
        ax.set_xticks([]); ax.set_yticks([]); ax.set_xlabel(""); ax.set_ylabel("")
        for sp in ax.spines.values():
            sp.set_visible(False)
        lab = f"{y}" + (" (Jan–Nov)" if y == 2026 else " (from 14 Feb)" if y == 2022 else "")
        ax.set_title(lab, loc="left", fontsize=9, color=INK)
    cb = fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=axes, orientation="horizontal",
                      fraction=0.025, pad=0.02, aspect=50)
    cb.set_label("Share of observed days classified red (>10% of aircraft reporting degraded accuracy)")
    cb.outline.set_visible(False)
    save(fig, "fig3_persistence_maps")


def fig4_events(d):
    panels = [("2023-10-07", "Levant core", "Oct 2023: Israel–Hamas war (Levant core)"),
              ("2025-05-07", "South Asia (Ind-Pak)", "May 2025: India–Pakistan strikes (South Asia)"),
              ("2025-06-13", "Persian Gulf", "Jun 2025: Israel–Iran war (Persian Gulf)"),
              ("2026-02-28", "Levant core", "Feb 2026: US/Israel–Iran war (Levant core)"),
              ("2026-02-28", "Eastern Mediterranean", "Feb 2026 (Eastern Mediterranean)"),
              ("2026-02-28", "Persian Gulf", "Feb 2026 (Persian Gulf)")]
    fig, axes = plt.subplots(3, 2, figsize=(7.2, 7.0))
    for ax, (dte, reg, title) in zip(axes.flat, panels):
        t0 = pd.Timestamp(dte)
        s = d[(d.region == reg)].set_index("date").sort_index()
        s = s[(s.index >= t0 - pd.Timedelta(days=90)) & (s.index < t0 + pd.Timedelta(days=90))]
        x = (s.index - t0).days
        ax.plot(x, 100 * s.share_red, color="#c3c2b7", lw=0.8)
        ax.plot(x, 100 * s.share_red.rolling(7, center=True, min_periods=4).mean(), color=CAT[0])
        for side in (x < 0, x >= 0):
            ax.hlines(100 * s.share_red[side].mean(), x[side].min(), x[side].max(), color=CAT[1], lw=1.2, ls="--")
        ax.axvline(0, color=INK2, lw=0.8, ls=":")
        ax.set_title(title, loc="left", fontsize=8)
        ax.set_ylim(bottom=0)
    for ax in axes[-1]:
        ax.set_xlabel("Days relative to event")
    for ax in axes[:, 0]:
        ax.set_ylabel("Red hexes (%)")
    axes[0, 0].plot([], [], color="#c3c2b7", lw=0.8, label="Daily")
    axes[0, 0].plot([], [], color=CAT[0], label="7-day mean")
    axes[0, 0].plot([], [], color=CAT[1], ls="--", label="Pre/post mean")
    axes[0, 0].legend(fontsize=7, loc="lower left")
    fig.tight_layout()
    save(fig, "fig7_event_raw")


def fig5_typology():
    t = pd.read_csv(RES / "typology_year.csv")
    t = t[t["class"] != "none"]
    classes = ["sporadic", "recurrent", "chronic"]
    cols = {"sporadic": "#f4b9a6", "recurrent": "#e0624a", "chronic": "#9b1d14"}
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9))
    for ax, (v, k, lab) in zip(axes, [("area_km2", 1e-6, "Area (million km²)"),
                                      ("aircraft_in_red", 1e-6, "Aircraft-hex observations in\nred hex-days (millions)")]):
        bottom = np.zeros(5)
        yrs = sorted(t.year.unique())
        for c in classes:
            vals = t[t["class"] == c].set_index("year").reindex(yrs)[v].values * k
            ax.bar([str(y) for y in yrs], vals, bottom=bottom, color=cols[c], label=c.capitalize(),
                   edgecolor="white", linewidth=1.0, width=0.65)
            bottom += vals
        ax.set_ylabel(lab)
        ax.grid(axis="x", visible=False)
    axes[0].legend(fontsize=7, loc="upper left", title="Hotspot class", title_fontsize=7)
    fig.text(0.5, -0.03, "2022 begins 14 Feb; 2026 ends 13 Nov. Classes: share of observed days red — sporadic ≤10%, recurrent 10–50%, chronic >50%.",
             ha="center", fontsize=6.5, color=INK2)
    fig.tight_layout()
    save(fig, "fig4_hotspot_typology")


def main():
    m = pd.read_csv(RES / "monthly_region.csv", parse_dates=["month"])
    d = pd.read_csv(DER / "daily_region.csv", parse_dates=["date"])
    d = d[~d.suspect.fillna(False)]
    fig1_global(m)
    fig2_heatmap(m)
    fig3_maps()
    fig4_events(d)
    fig5_typology()
    print("figures done")


if __name__ == "__main__":
    main()
