"""Aggregate hex-day panel into analysis series.

Analytic sample: hex-days with n = good + bad >= MIN_N aircraft (default 3).
Classes follow GPSJam (pct_bad > 10 = high/red; 2-10 = medium/yellow).

Outputs (data/derived/):
  daily_region.csv   date x region aggregates (+ 'Global', 'Turkey (land)')
  hex_year.csv       hex x year persistence statistics
  hexday_focus.parquet   hex-day states for focal regions (for Markov/contagion)
"""
import sys
from pathlib import Path

import h3
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "derived"
OUT.mkdir(parents=True, exist_ok=True)
MIN_N = int(sys.argv[1]) if len(sys.argv) > 1 else 3
SUFFIX = "" if MIN_N == 3 else f"_n{MIN_N}"


def main() -> None:
    p = pd.read_parquet(ROOT / "data" / "panel.parquet")
    hx = pd.read_parquet(ROOT / "data" / "hexes.parquet")
    hx["area_km2"] = [h3.cell_area(h3.int_to_str(int(x)), unit="km^2") for x in hx.hex]
    man = pd.read_csv(ROOT / "data" / "raw" / "gpsjam_manifest.csv", parse_dates=["date"])

    p["n"] = p["good"] + p["bad"]
    p = p[p["n"] >= MIN_N].copy()
    pct = 100.0 * (p["bad"] - 1).clip(lower=0) / p["n"]
    p["red"] = (pct > 10).astype("int8")
    p["yellow"] = ((pct >= 2) & (pct <= 10)).astype("int8")
    p = p.merge(hx[["hex", "region", "iso3", "area_km2"]], on="hex", how="left")
    p["n_red"] = p["n"] * p["red"]
    p["bad_red"] = p["bad"] * p["red"]
    p["area_red"] = p["area_km2"] * p["red"]

    agg = dict(hexes=("hex", "size"), red=("red", "sum"), yellow=("yellow", "sum"),
               aircraft=("n", "sum"), bad=("bad", "sum"), aircraft_in_red=("n_red", "sum"),
               bad_in_red=("bad_red", "sum"), area_red_km2=("area_red", "sum"))
    g = p.groupby("date").agg(**agg).reset_index().assign(region="Global")
    r = p.groupby(["date", "region"]).agg(**agg).reset_index()
    t = p[p.iso3 == "TUR"].groupby("date").agg(**agg).reset_index().assign(region="Turkey (land)")
    hl = hx[(hx.lon >= 34.0) & (hx.lon < 36.7) & (hx.lat >= 31.0) & (hx.lat < 34.7)].hex
    lv = p[p.hex.isin(hl)].groupby("date").agg(**agg).reset_index().assign(region="Levant core")
    d = pd.concat([g, r, t, lv], ignore_index=True)
    d["share_red"] = d["red"] / d["hexes"]
    d["share_aircraft_red"] = d["aircraft_in_red"] / d["aircraft"]
    d = d.merge(man[["date", "suspect", "source"]], on="date", how="left")
    d.to_csv(OUT / f"daily_region{SUFFIX}.csv", index=False)
    print("daily_region", d.shape)

    if MIN_N != 3:
        return

    # hex-year persistence
    p["year"] = p["date"].dt.year
    hy = p.groupby(["hex", "year"]).agg(days_obs=("red", "size"), days_red=("red", "sum"),
                                        aircraft=("n", "sum"), aircraft_in_red=("n_red", "sum")).reset_index()
    hy = hy.merge(hx[["hex", "region", "iso3", "lat", "lon", "area_km2"]], on="hex", how="left")
    hy["freq_red"] = hy["days_red"] / hy["days_obs"]
    hy.to_csv(OUT / "hex_year.csv", index=False)
    print("hex_year", hy.shape)

    # hex-day states for focal regions (+ all of Turkey)
    foc = p[(p.region != "Rest of world") | (p.iso3 == "TUR")][["date", "hex", "region", "iso3", "red", "n"]]
    foc.to_parquet(OUT / "hexday_focus.parquet", index=False)
    print("focus rows", len(foc))


if __name__ == "__main__":
    main()
