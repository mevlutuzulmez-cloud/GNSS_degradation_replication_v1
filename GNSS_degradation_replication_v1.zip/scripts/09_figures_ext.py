"""Figures for the extended analyses (landscape-friendly sizes)."""
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
FIG, RES = ROOT / "figures", ROOT / "results"
CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
mpl.rcParams.update({
    "font.family": "Times New Roman", "font.size": 10, "axes.edgecolor": INK2, "axes.labelcolor": INK,
    "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
    "legend.frameon": False, "lines.linewidth": 1.8, "savefig.dpi": 300, "savefig.bbox": "tight",
    "mathtext.fontset": "stix",
})
REG_COL = {"Baltic Sea": CAT[0], "Black Sea": CAT[1], "Eastern Mediterranean": CAT[2],
           "Myanmar": CAT[6], "South Asia (Ind-Pak)": CAT[3], "Persian Gulf": CAT[7],
           "SW United States": "#8a8984"}


def save(fig, name):
    fig.savefig(FIG / f"{name}.png"); fig.savefig(FIG / f"{name}.pdf"); plt.close(fig)


def fig_airports():
    c = pd.read_csv(RES / "revision" / "E_airport_counts_variants.csv")
    c = c[c["sample"] == "fixed set"]
    v = pd.read_csv(RES / "revision" / "E_airport_variants.csv")
    fig, axes = plt.subplots(1, 2, figsize=(11.0, 5.4), gridspec_kw={"width_ratios": [1, 1.5]})
    ax = axes[0]
    series = [("any7_ge10", "Any of 7 vicinity cells", CAT[0], "-"), ("full7_ge10", "All 7 cells observed", CAT[2], "-"),
              ("two7_ge10", "At least 2 of 7 cells", CAT[3], "-"), ("home_ge10", "Home cell only", CAT[1], "-")]
    for col, lab, colr, ls in series:
        ax.plot(c.year, c[col], "o", ls=ls, color=colr, label=lab, ms=6)
        dy = {"full7_ge10": 3.5, "two7_ge10": -3.5}.get(col, 0)
        ax.text(c.year.iloc[-1] + 0.08, c[col].iloc[-1] + dy, str(int(c[col].iloc[-1])), va="center", fontsize=8.5, color=INK)
    ax.set_xticks(c.year, c.year.astype(str)); ax.set_xlim(2021.7, 2026.5)
    ax.set_ylabel("Airports with vicinity red on ≥10% of days")
    ax.set_title("(a) Fixed set of 2,170 airports, four definitions", loc="left", fontsize=10.5)
    ax.legend(loc="upper left", fontsize=8.5)
    ax = axes[1]
    t = v[(v.year == 2026) & (v.type == "large_airport") & (v.iata_code != "ESB")].sort_values(
        ["share_any7", "share_home"], ascending=False).head(20).iloc[::-1]
    p22 = v[v.year == 2022].set_index("ident").share_any7
    lab = [f"{n.replace(' International Airport','').replace(' Airport','')} ({i})" for n, i in zip(t.name, t.iata_code)]
    y = np.arange(len(t))
    ax.hlines(y, 0, 100 * t.share_any7, color=GRID, lw=2)
    ax.scatter(100 * t.share_any7, y, color=CAT[0], s=42, zorder=3, label="2026, any of 7 cells")
    ax.scatter(100 * t.share_home, y, color=CAT[1], s=36, marker="s", zorder=3, label="2026, home cell only")
    ax.scatter(100 * p22.reindex(t.ident).values, y, color="#8a8984", s=26, marker="D", zorder=3, label="2022, any of 7 cells")
    ax.set_yticks(y, lab, fontsize=8.5)
    ax.set_xlabel("Share of observed days with a red cell in the airport vicinity (%)")
    ax.set_xlim(-2, 104)
    ax.set_title("(b) Large airports most often affected in 2026", loc="left", fontsize=10.5)
    ax.legend(loc="upper center", bbox_to_anchor=(0.4, -0.1), ncol=3, fontsize=8.5)
    fig.tight_layout()
    save(fig, "fig9_airports")


def fig_km():
    k = pd.read_csv(RES / "episodes_km_curves.csv")
    fig, ax = plt.subplots(figsize=(8.5, 5.0))
    for reg, col in REG_COL.items():
        g = k[k.region == reg]
        ax.step(np.r_[0, g.t], np.r_[1, g.S], where="post", color=col, label=reg.replace("(Ind-Pak)", "(India–Pakistan)"),
                lw=2.2 if reg != "SW United States" else 1.4, ls="-" if reg != "SW United States" else "--")
    ax.set_xscale("log")
    ax.set_xlim(1, 300); ax.set_ylim(0, 1.02)
    ax.set_xticks([1, 2, 3, 5, 7, 14, 30, 60, 120, 240], ["1", "2", "3", "5", "7", "14", "30", "60", "120", "240"])
    ax.set_xlabel("Episode duration (consecutive red days, log scale)")
    ax.set_ylabel("Probability that the episode is still ongoing")
    ax.legend(fontsize=9, ncol=2, loc="upper right")
    save(fig, "fig5_episode_survival")


def fig_decay():
    d = pd.read_csv(RES / "distance_decay_fe.csv")
    fig, ax = plt.subplots(figsize=(7.5, 4.6))
    ring = {"s1": 1, "s2": 2, "s3": 3}
    for (samp, col, off, lab) in [("onset", CAT[0], -0.08, "Onset (cell not red at t−1)"),
                                  ("persistence", CAT[1], 0.08, "Persistence (cell red at t−1)")]:
        g = d[d["sample"] == samp]
        xs = np.array([ring[c] for c in g.Coefficient]) + off
        ax.errorbar(xs, g.Estimate, yerr=[g.Estimate - g["2.5%"], g["97.5%"] - g.Estimate], fmt="o-", color=col,
                    capsize=4, ms=7, label=lab)
        for xx, e in zip(xs, g.Estimate):
            ax.text(xx + 0.06, e + 0.6, f"{e:.1f}", fontsize=9, color=INK)
    ax.set_xticks([1, 2, 3], ["Ring 1\n(adjacent, ≈45 km)", "Ring 2\n(≈90 km)", "Ring 3\n(≈135 km)"])
    ax.set_ylabel("Effect of all cells in ring being red at t−1\n(percentage points, 95% CI)")
    ax.set_ylim(0, 36)
    ax.legend(fontsize=9)
    save(fig, "fig6_distance_decay")


def fig_dynamic():
    d = pd.read_csv(RES / "revision" / "D_dynamic_placebo_bands.csv")
    panels = [("2023-10-07", "Levant core", "(a) Oct 2023 Israel–Hamas war: Levant core"),
              ("2025-05-07", "South Asia (Ind-Pak)", "(b) May 2025 India–Pakistan strikes: South Asia"),
              ("2025-06-13", "Persian Gulf", "(c) Jun 2025 Israel–Iran war: Persian Gulf"),
              ("2026-02-28", "Levant core", "(d) Feb 2026 US/Israel–Iran war: Levant core"),
              ("2026-02-28", "Eastern Mediterranean", "(e) Feb 2026: Eastern Mediterranean"),
              ("2026-02-28", "Persian Gulf", "(f) Feb 2026: Persian Gulf")]
    fig, axes = plt.subplots(2, 3, figsize=(11.5, 6.2), sharex=True)
    for ax, (ev, reg, title) in zip(axes.flat, panels):
        g = d[(d.event == ev) & (d.region == reg)].sort_values("week")
        ax.axhline(0, color=INK2, lw=0.8)
        ax.axvline(-0.5, color=INK2, lw=0.8, ls=":")
        ax.fill_between(g.week, g.null_lo, g.null_hi, color="#b9b8b2", alpha=0.45, lw=0,
                        label="95% placebo range")
        ax.plot(g.week, g.coef, "o-", color=CAT[0], ms=3.5, lw=1.6, label="Observed")
        ax.set_title(title, loc="left", fontsize=9.5)
    axes.flat[0].legend(fontsize=8, loc="upper left")
    for ax in axes[1]:
        ax.set_xlabel("Weeks relative to event (reference: mean of weeks −12 to −1)")
    for ax in axes[:, 0]:
        ax.set_ylabel("Change in red-hex share (pp)")
    fig.tight_layout()
    save(fig, "fig8_dynamic_events")


def fig_nowcast():
    c = pd.read_csv(RES / "revision" / "C_nowcast_extended.csv")
    cb = pd.read_csv(RES / "revision" / "C_calibration_full.csv")
    models = ["Climatology: 365-day frequency", "Climatology: 28-day frequency", "Persistence only",
              "Own history", "Own history + 28-day", "Full"]
    labels = [l.replace("|", "\n") for l in ["Static map|(365-day)", "Static map|(28-day)", "Persistence|(t−1)",
                                             "Own history|(t−1, 7-day)", "Own history|+ 28-day", "Full|(+ rings 1–3)"]]
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.9), gridspec_kw={"width_ratios": [1.6, 1]})
    ax = axes[0]
    x = np.arange(len(models)); w = 0.2
    series = [("All focal", "auc", CAT[0], "AUC, all cell-days"), ("All focal", "pr_auc", "#9ec5ef", "PR-AUC, all cell-days"),
              ("Onsets (not red at t−1)", "auc", CAT[1], "AUC, onsets"), ("Onsets (not red at t−1)", "pr_auc", "#f5b796", "PR-AUC, onsets")]
    for k, (sub, met, col, lab) in enumerate(series):
        v = [c[(c.model == m) & (c.subset == sub)][met].iloc[0] for m in models]
        ax.bar(x + (k - 1.5) * w, v, w, color=col, label=lab)
        if met == "auc" or True:
            for xi, vi in zip(x, v):
                ax.text(xi + (k - 1.5) * w, vi + 0.012, f"{vi:.2f}", ha="center", fontsize=6.8, rotation=90, color=INK)
    ax.set_xticks(x, labels, fontsize=8.5); ax.set_ylim(0, 1.12); ax.grid(axis="x", visible=False)
    ax.set_ylabel("Score (test year 2026)")
    ax.set_title("(a) Discrimination: static maps vs dynamic models", loc="left", fontsize=10.5)
    ax.legend(fontsize=8, ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.17))
    ax = axes[1]
    ax.plot([0, 1], [0, 1], color="#b9b8b2", ls="--", lw=1)
    ax.plot(cb.p_mean, cb.obs_rate, "o-", color=CAT[0], ms=5)
    ax.set_xlabel("Predicted probability (full model)"); ax.set_ylabel("Observed share red")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.set_aspect("equal")
    ax.set_title("(b) Calibration, 2026", loc="left", fontsize=10.5)
    fig.tight_layout()
    save(fig, "fig10_nowcast")


if __name__ == "__main__":
    fig_airports(); fig_km(); fig_decay(); fig_dynamic(); fig_nowcast()
    print("ok")
