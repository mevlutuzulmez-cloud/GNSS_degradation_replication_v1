"""Render manuscript tables (Markdown) directly from results/ CSVs."""
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"
OUT = ROOT / "manuscript" / "tables.md"
REG = ["Global", "Baltic Sea", "Black Sea", "Eastern Mediterranean", "Levant core", "Iraq-Syria-W. Iran",
       "Persian Gulf", "South Asia (Ind-Pak)", "Myanmar", "Turkey (land)", "SW United States", "Rest of world"]


def f(x, k=1):
    return f"{x:,.{k}f}"


def pfmt(p):
    return "<0.001" if p < 0.001 else f"{p:.3f}"


def t1():
    d = pd.read_csv(RES / "descriptives_region_year.csv")
    rows = ["| Region | 2022 | 2023 | 2024 | 2025 | 2026 |", "|---|---|---|---|---|---|"]
    for r in REG:
        s = d[d.region == r].set_index("year")
        rows.append(f"| {r} | " + " | ".join(f(100 * s.loc[y, 'share_red'], 1) if y in s.index else "–" for y in range(2022, 2027)) + " |")
    return "\n".join(rows)


def t1b():
    d = pd.read_csv(RES / "descriptives_region_year.csv")
    rows = ["| Region | 2022 | 2023 | 2024 | 2025 | 2026 |", "|---|---|---|---|---|---|"]
    for r in REG:
        s = d[d.region == r].set_index("year")
        rows.append(f"| {r} | " + " | ".join(f(100 * s.loc[y, 'share_aircraft_red'], 1) if y in s.index else "–" for y in range(2022, 2027)) + " |")
    return "\n".join(rows)


def t2():
    t = pd.read_csv(RES / "trend_tests.csv")
    t = t[t["var"] == "share_red"].set_index("region")
    rb = pd.read_csv(RES / "robustness_trends.csv")
    rows = ["| Region | First 12 mo. (%) | Last 12 mo. (%) | Kendall τ | Sen slope (pp/yr) | p (main) | p (n≥10) | p (pre-source change) | p (excl. Mar–Jun 2026) |",
            "|---|---|---|---|---|---|---|---|---|"]
    for r in REG:
        if r not in t.index:
            continue
        s = t.loc[r]
        rr = rb[rb.region == r].set_index("variant").p
        rows.append(f"| {r} | {f(100*s.first12,2)} | {f(100*s.last12,2)} | {s.tau:.2f} | {100*12*s.sen_slope_per_month:.2f} | {pfmt(s.p)} | "
                    f"{pfmt(rr['n>=10'])} | {pfmt(rr['pre source change (<2026-08-27)'])} | {pfmt(rr['excl. Mar-Jun 2026'])} |")
    return "\n".join(rows)


def t3():
    t = pd.read_csv(RES / "typology_year.csv")
    rows = ["| Year | Sporadic hexes | Recurrent hexes | Chronic hexes | Recurrent + chronic area (10³ km²) | Aircraft-hex obs. in red hex-days, recurrent + chronic (10⁶) |",
            "|---|---|---|---|---|---|"]
    for y in range(2022, 2027):
        s = t[t.year == y].set_index("class")
        rc = s.loc[["recurrent", "chronic"]]
        rows.append(f"| {y} | {int(s.loc['sporadic','hexes']):,} | {int(s.loc['recurrent','hexes']):,} | {int(s.loc['chronic','hexes']):,} | "
                    f"{f(rc.area_km2.sum()/1e3,0)} | {f(rc.aircraft_in_red.sum()/1e6,2)} |")
    return "\n".join(rows)


def t4():
    e = pd.read_csv(RES / "event_studies.csv")
    lab = {"share_red": "Hex share", "share_aircraft_red": "Aircraft share"}
    rows = ["| Event (date) | Region | Outcome | Pre mean (%) | Post mean (%) | Level change (pp) | HAC SE | p (HAC) | p (placebo) |",
            "|---|---|---|---|---|---|---|---|---|"]
    for _, s in e.iterrows():
        rows.append(f"| {s.event} ({s.date}) | {s.region} | {lab[s['var']]} | {f(s.pre_mean)} | {f(s.post_mean)} | {s.level:+.1f} | {s.level_se:.1f} | {pfmt(s.level_p)} | {pfmt(s.p_placebo)} |")
    return "\n".join(rows)


def t5():
    c = pd.read_csv(RES / "contagion_fe.csv")
    rows = ["| Sample | Coefficient | Estimate (pp) | Cluster-robust SE | 95% CI | N (hex-days) |", "|---|---|---|---|---|---|"]
    names = {"nb_red_lag": "Share of neighbouring hexes red at t−1", "prev_red": "Own hex red at t−1"}
    for _, s in c.iterrows():
        rows.append(f"| {s['sample']} | {names[s.Coefficient]} | {s.Estimate:.1f} | {s['Std. Error']:.2f} | [{s['2.5%']:.1f}, {s['97.5%']:.1f}] | {int(s.nobs):,} |")
    m = open(RES / "markov_overall.txt").read().split("\n")
    return "\n".join(rows) + "\n\n" + "; ".join(x for x in m if x)


def t6():
    z = pd.read_csv(RES / "turkey_zones.csv").set_index("zone")
    tr = pd.read_csv(RES / "turkey_trends.csv")
    rows = ["| Turkish zone (land hexes) | 2022 | 2023 | 2024 | 2025 | 2026 |", "|---|---|---|---|---|---|"]
    for zz in ["North/Black Sea coast", "Southeast/East", "South/Mediterranean", "Central/West"]:
        rows.append(f"| {zz} (excl. Ankara cluster) | " + " | ".join(f(100 * z.loc[zz, str(y)], 1) for y in range(2022, 2027)) + " |")
    for _, s in tr.iterrows():
        rows.append(f"| {s.series} | " + " | ".join(f(100 * s[f'share_red_{y}'], 1) for y in range(2022, 2027)) + " |")
    trend = "; ".join(f"{s.series}: τ = {s.tau:.2f}, p = {pfmt(s.p)}" for _, s in tr.iterrows())
    return "\n".join(rows) + "\n\nModified Mann–Kendall on monthly series — " + trend


def main():
    parts = {"T1 share red": t1(), "T1b aircraft share": t1b(), "T2 trends": t2(), "T3 typology": t3(),
             "T4 events": t4(), "T5 contagion": t5(), "T6 Turkey": t6()}
    OUT.write_text("\n\n".join(f"## {k}\n\n{v}" for k, v in parts.items()), encoding="utf8")
    print(OUT.read_text(encoding="utf8"))


if __name__ == "__main__":
    main()
