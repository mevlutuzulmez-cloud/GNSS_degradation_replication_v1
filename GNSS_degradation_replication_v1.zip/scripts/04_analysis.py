"""Statistical analysis.

1. Descriptives by year (global, regions, Turkey).
2. Trend tests on monthly series (Hamed-Rao modified Mann-Kendall + Sen slope).
3. Hotspot persistence typology by hex-year.
4. Interrupted time-series event studies with Newey-West SEs and
   in-region placebo (permutation) inference.
5. Markov persistence of hex states and spatial contagion (two-way FE LPM).

All results written to results/ as CSV / TXT.
"""
from pathlib import Path

import h3
import numpy as np
import pandas as pd
import pymannkendall as mk
import statsmodels.formula.api as smf

ROOT = Path(__file__).resolve().parents[1]
DER = ROOT / "data" / "derived"
RES = ROOT / "results"
RES.mkdir(exist_ok=True)

EVENTS = [
    # (label, date, region analysed)
    ("Israel-Hamas war onset", "2023-10-07", "Eastern Mediterranean"),
    ("Israel-Hamas war onset", "2023-10-07", "Levant core"),
    ("India-Pakistan strikes (Op. Sindoor)", "2025-05-07", "South Asia (Ind-Pak)"),
    ("Israel-Iran war onset", "2025-06-13", "Persian Gulf"),
    ("Israel-Iran war onset", "2025-06-13", "Iraq-Syria-W. Iran"),
    ("Israel-Iran war onset", "2025-06-13", "Levant core"),
    ("US-Israel strikes on Iran", "2026-02-28", "Persian Gulf"),
    ("US-Israel strikes on Iran", "2026-02-28", "Iraq-Syria-W. Iran"),
    ("US-Israel strikes on Iran", "2026-02-28", "Eastern Mediterranean"),
    ("US-Israel strikes on Iran", "2026-02-28", "Levant core"),
    ("US-Israel strikes on Iran", "2026-02-28", "Turkey (land)"),
]
WIN = 90  # days either side


def load_daily(suffix: str = "") -> pd.DataFrame:
    d = pd.read_csv(DER / f"daily_region{suffix}.csv", parse_dates=["date"])
    return d[~d["suspect"].fillna(False)]


def descriptives(d: pd.DataFrame) -> None:
    d = d.copy()
    d["year"] = d.date.dt.year
    t = d.groupby(["region", "year"]).agg(days=("date", "nunique"), hexes_obs=("hexes", "mean"),
                                          red_hexes=("red", "mean"), share_red=("share_red", "mean"),
                                          share_aircraft_red=("share_aircraft_red", "mean"),
                                          aircraft_in_red=("aircraft_in_red", "mean"),
                                          area_red_km2=("area_red_km2", "mean")).reset_index()
    t.to_csv(RES / "descriptives_region_year.csv", index=False)


def monthly(d: pd.DataFrame) -> pd.DataFrame:
    d = d.copy()
    d["month"] = d.date.dt.to_period("M").dt.to_timestamp()
    m = d.groupby(["region", "month"]).agg(share_red=("share_red", "mean"),
                                           share_aircraft_red=("share_aircraft_red", "mean"),
                                           red=("red", "mean"), area_red_km2=("area_red_km2", "mean"),
                                           aircraft_in_red=("aircraft_in_red", "mean"),
                                           days=("date", "nunique")).reset_index()
    # drop incomplete months (first and last partial months)
    m = m[m.days >= 20]
    m.to_csv(RES / "monthly_region.csv", index=False)
    return m


def trends(m: pd.DataFrame) -> None:
    rows = []
    for (reg), g in m.groupby("region"):
        for var in ["share_red", "share_aircraft_red", "area_red_km2"]:
            y = g.sort_values("month")[var].values
            r = mk.hamed_rao_modification_test(y)
            rows.append(dict(region=reg, var=var, n=len(y), trend=r.trend, tau=r.Tau, z=r.z, p=r.p,
                             sen_slope_per_month=r.slope, first12=np.mean(y[:12]), last12=np.mean(y[-12:])))
    pd.DataFrame(rows).to_csv(RES / "trend_tests.csv", index=False)


def typology() -> None:
    hy = pd.read_csv(DER / "hex_year.csv")
    hy = hy[hy.days_obs >= 30].copy()
    hy["class"] = pd.cut(hy.freq_red, [-0.01, 0.0, 0.10, 0.50, 1.0],
                         labels=["none", "sporadic", "recurrent", "chronic"])
    t = hy.groupby(["year", "class"], observed=False).agg(hexes=("hex", "size"), area_km2=("area_km2", "sum"),
                                                          aircraft_in_red=("aircraft_in_red", "sum")).reset_index()
    t.to_csv(RES / "typology_year.csv", index=False)
    tr = hy[hy["class"].isin(["recurrent", "chronic"])].groupby(["year", "region", "class"], observed=True).agg(
        hexes=("hex", "size"), area_km2=("area_km2", "sum")).reset_index()
    tr.to_csv(RES / "typology_year_region.csv", index=False)
    hy.to_csv(DER / "hex_year_class.csv", index=False)


def its(series: pd.DataFrame, t0: pd.Timestamp, var: str):
    s = series[(series.date >= t0 - pd.Timedelta(days=WIN)) & (series.date < t0 + pd.Timedelta(days=WIN))].copy()
    if len(s) < WIN:  # insufficient data
        return None
    s["t"] = (s.date - t0).dt.days
    s["post"] = (s.t >= 0).astype(int)
    s["t_post"] = s.t * s.post
    s["dow"] = s.date.dt.dayofweek.astype(str)
    s["y"] = 100 * s[var]
    fit = smf.ols("y ~ t + post + t_post + C(dow)", data=s).fit(cov_type="HAC", cov_kwds={"maxlags": 14})
    pre_mean = s.loc[s.post == 0, "y"].mean()
    post_mean = s.loc[s.post == 1, "y"].mean()
    return dict(level=fit.params["post"], level_se=fit.bse["post"], level_p=fit.pvalues["post"],
                slope=fit.params["t_post"], slope_p=fit.pvalues["t_post"], pre_mean=pre_mean,
                post_mean=post_mean, n=len(s))


def event_studies(d: pd.DataFrame) -> None:
    rows = []
    for label, date, reg in EVENTS:
        t0 = pd.Timestamp(date)
        ser = d[d.region == reg].sort_values("date")
        for var in ["share_red", "share_aircraft_red"]:
            r = its(ser, t0, var)
            if r is None:
                continue
            # placebo: pseudo-events in the 365 days before the real window, one per 7 days
            plac = []
            for k in range(WIN + 7, WIN + 365, 7):
                pr = its(ser, t0 - pd.Timedelta(days=k), var)
                if pr is not None:
                    plac.append(pr["level"])
            plac = np.array(plac)
            p_perm = (np.sum(np.abs(plac) >= abs(r["level"])) + 1) / (len(plac) + 1)
            rows.append(dict(event=label, date=date, region=reg, var=var, **r,
                             n_placebo=len(plac), p_placebo=p_perm))
    pd.DataFrame(rows).to_csv(RES / "event_studies.csv", index=False)


def markov_and_contagion() -> None:
    f = pd.read_parquet(DER / "hexday_focus.parquet")
    f = f.sort_values(["hex", "date"])
    f["prev_date"] = f.groupby("hex").date.shift()
    f["prev_red"] = f.groupby("hex").red.shift()
    cons = f[(f.date - f.prev_date).dt.days == 1].copy()
    cons["year"] = cons.date.dt.year
    tm = cons.groupby(["region", "year", "prev_red"]).red.mean().unstack("prev_red").reset_index()
    tm.columns = ["region", "year", "p_onset", "p_persist"]
    # expected episode length 1/(1-p_persist)
    tm["exp_episode_days"] = 1 / (1 - tm.p_persist)
    tm.to_csv(RES / "markov_region_year.csv", index=False)
    g = cons.groupby("prev_red").red.mean()
    with open(RES / "markov_overall.txt", "w") as fh:
        fh.write(f"P(red|not red yesterday)={g.loc[0]:.4f}\nP(red|red yesterday)={g.loc[1]:.4f}\n"
                 f"n={len(cons)}\n")

    # spatial contagion: share of first-ring neighbours red at t-1
    red_lookup = f.set_index(["hex", "date"]).red
    hexes = f.hex.unique()
    nb = {hx: [h3.str_to_int(n) for n in h3.grid_ring(h3.int_to_str(int(hx)), 1)] for hx in hexes}
    pairs = pd.DataFrame([(h, n) for h, ns in nb.items() for n in ns], columns=["hex", "nb"])
    prev = f[["hex", "date", "red"]].copy()
    prev["date"] = prev["date"] + pd.Timedelta(days=1)
    prev = prev.rename(columns={"hex": "nb", "red": "nb_red_lag"})
    x = pairs.merge(prev, on="nb", how="inner")
    nbs = x.groupby(["hex", "date"]).agg(nb_red_lag=("nb_red_lag", "mean"), nb_obs=("nb_red_lag", "size")).reset_index()
    c = cons.merge(nbs, on=["hex", "date"], how="inner")
    c = c[c.nb_obs >= 2]
    c["red100"] = 100 * c.red
    c["month"] = c.date.dt.to_period("M").astype(str)
    c["reg_date"] = c.region + "_" + c.date.dt.strftime("%Y-%m-%d")
    import pyfixest as pf
    res = []
    for name, sub in [("all", c), ("onset (not red at t-1)", c[c.prev_red == 0]),
                      ("persistence (red at t-1)", c[c.prev_red == 1])]:
        fml = "red100 ~ nb_red_lag + prev_red | hex + reg_date" if name == "all" else "red100 ~ nb_red_lag | hex + reg_date"
        m = pf.feols(fml, data=sub, vcov={"CRV1": "hex"})
        t = m.tidy().reset_index()
        t["sample"] = name
        t["nobs"] = m._N
        res.append(t)
    pd.concat(res).to_csv(RES / "contagion_fe.csv", index=False)


def robustness() -> None:
    """Trend tests (share_red) under (a) n>=10 threshold, (b) truncation before the
    2026-08-27 data-source change, (c) excluding Mar-Jun 2026 war months."""
    rows = []
    variants = {
        "main (n>=3)": load_daily(),
        "n>=10": load_daily("_n10"),
    }
    base = load_daily()
    variants["pre source change (<2026-08-27)"] = base[base.date < "2026-08-27"]
    variants["excl. Mar-Jun 2026"] = base[(base.date < "2026-03-01") | (base.date >= "2026-07-01")]
    for name, d in variants.items():
        d = d.copy()
        d["month"] = d.date.dt.to_period("M").dt.to_timestamp()
        m = d.groupby(["region", "month"]).agg(y=("share_red", "mean"), days=("date", "nunique")).reset_index()
        m = m[m.days >= 20]
        for reg, g in m.groupby("region"):
            r = mk.hamed_rao_modification_test(g.sort_values("month").y.values)
            rows.append(dict(variant=name, region=reg, n=len(g), tau=r.Tau, p=r.p, sen=r.slope,
                             mean=g.y.mean()))
    pd.DataFrame(rows).to_csv(RES / "robustness_trends.csv", index=False)


def main() -> None:
    robustness()
    d = load_daily()
    descriptives(d)
    m = monthly(d)
    trends(m)
    typology()
    event_studies(d)
    markov_and_contagion()
    print("done")


if __name__ == "__main__":
    main()
