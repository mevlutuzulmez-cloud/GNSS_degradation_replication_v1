"""Download all GPSJam daily H3 (res 4) files listed in the manifest.

Source: https://gpsjam.org (John Wiseman), derived from ADS-B Exchange /
adsb.lol / airplanes.live NACp values. Files are gzip-encoded CSV
(hex, count_good_aircraft, count_bad_aircraft).
"""
import gzip
import io
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "gpsjam"
END_DATE = "2026-11-13"  # last day used in the article; raise to extend the record
OUT.mkdir(parents=True, exist_ok=True)
UA = {"User-Agent": "academic-research-client/1.0"}


def get(url: str) -> bytes:
    for attempt in range(5):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=60) as r:
                return r.read()
        except Exception as e:  # noqa: BLE001
            if attempt == 4:
                raise
            time.sleep(2 * (attempt + 1))
    return b""


def maybe_gunzip(b: bytes) -> bytes:
    return gzip.decompress(b) if b[:2] == b"\x1f\x8b" else b


def main() -> None:
    man = maybe_gunzip(get("https://gpsjam.org/data/manifest.csv"))
    (ROOT / "data" / "raw" / "gpsjam_manifest.csv").write_bytes(man)
    dates = pd.read_csv(io.BytesIO(man))["date"].tolist()
    dates = [d for d in dates if d <= END_DATE]  # reproduce the published record

    def fetch(d: str) -> str:
        p = OUT / f"{d}.csv"
        if p.exists() and p.stat().st_size > 0:
            return "skip"
        try:
            p.write_bytes(maybe_gunzip(get(f"https://gpsjam.org/data/{d}-h3_4.csv")))
            return "ok"
        except Exception as e:  # noqa: BLE001
            return f"fail {d} {e}"

    with ThreadPoolExecutor(max_workers=6) as ex:
        res = list(ex.map(fetch, dates))
    fails = [r for r in res if r.startswith("fail")]
    print(f"dates={len(dates)} ok={res.count('ok')} skip={res.count('skip')} fail={len(fails)}")
    for f in fails:
        print(f)
    sys.exit(0)


if __name__ == "__main__":
    main()
