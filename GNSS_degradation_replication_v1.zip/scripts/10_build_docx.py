"""Build the submission DOCX: pandoc for conversion, python-docx for journal formatting.

- Times New Roman everywhere; title and level-1 headings 14 pt bold; level-2 headings 12 pt bold.
- Every run of tables/figures (with their captions and notes) is placed in a landscape section.
- Three-line academic tables with shaded header, repeated header row, numeric columns centred.
- Continuous line numbers and page numbers (Elsevier review format).

Usage: python 10_build_docx.py [manuscript.md] [out.docx]
"""
import copy
import re
import subprocess
import sys
import tempfile
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Emu, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[1]
MS = ROOT / "manuscript"
SRC = Path(sys.argv[1]) if len(sys.argv) > 1 else MS / "manuscript.md"
OUT = Path(sys.argv[2]) if len(sys.argv) > 2 else MS / "GNSS_interference_SafetyScience.docx"
FONT = "Times New Roman"
A4_W, A4_H, MARGIN = Cm(21.0), Cm(29.7), Cm(2.5)
LAND_TEXT_W = Emu(A4_H - 2 * MARGIN)     # 24.7 cm
LAND_TEXT_H = Emu(A4_W - 2 * MARGIN)     # 16.0 cm


# ---------------------------------------------------------------- markdown pre-processing
def preprocess(md: str) -> str:
    fm_end = md.index("\n---", 3)
    front, body = md[:fm_end], md[fm_end:]
    front = "\n".join(l for l in front.splitlines() if not l.startswith("author:"))
    body = "\n".join(l for l in body.splitlines() if l.strip() != "---")
    md = front + "\n---\n" + body
    # author block: hard line breaks
    md = md.replace("**Mevlüt Üzülmez**\n", "**Mevlüt Üzülmez**\\\n")
    md = re.sub(r"(Kayseri, Türkiye)\n(ORCID)", r"\1\\\n\2", md)
    return md


def run_pandoc(md_text: str, out: Path):
    with tempfile.NamedTemporaryFile("w", suffix=".md", delete=False, encoding="utf-8", dir=MS) as f:
        f.write(md_text)
        tmp = Path(f.name)
    try:
        subprocess.run(["pandoc", str(tmp), "-f", "markdown", "-t", "docx", "-o", str(out),
                        f"--resource-path={MS}"], check=True, cwd=MS)
    finally:
        tmp.unlink()


# ---------------------------------------------------------------- helpers
def set_font(rpr_parent, size=None, bold=None, color_black=True):
    rpr = rpr_parent.get_or_add_rPr() if hasattr(rpr_parent, "get_or_add_rPr") else rpr_parent
    fonts = rpr.find(qn("w:rFonts"))
    if fonts is None:
        fonts = OxmlElement("w:rFonts"); rpr.insert(0, fonts)
    for a in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
        fonts.set(qn(a), FONT)
    for a in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
        if fonts.get(qn(a)) is not None:
            del fonts.attrib[qn(a)]


def style_font(style, size, bold=False, italic=False, align=None, before=None, after=None):
    style.font.name = FONT
    style.font.size = Pt(size)
    style.font.bold = bold
    style.font.italic = italic
    style.font.color.rgb = RGBColor(0, 0, 0)
    set_font(style.element.get_or_add_rPr())
    pf = style.paragraph_format
    if align is not None:
        pf.alignment = align
    if before is not None:
        pf.space_before = Pt(before)
    if after is not None:
        pf.space_after = Pt(after)


def para_text(p):
    return "".join(t.text or "" for t in p.iter(qn("w:t")))


def is_float_par(p):
    return bool(p.findall(".//" + qn("w:drawing")))


def make_sectPr(template, landscape):
    s = copy.deepcopy(template)
    for child in list(s):
        if child.tag in (qn("w:headerReference"), qn("w:footerReference")):
            s.remove(child)
    pgSz = s.find(qn("w:pgSz"))
    if pgSz is None:
        pgSz = OxmlElement("w:pgSz"); s.append(pgSz)
    w, h = (A4_H, A4_W) if landscape else (A4_W, A4_H)
    pgSz.set(qn("w:w"), str(int(w.twips))); pgSz.set(qn("w:h"), str(int(h.twips)))
    if landscape:
        pgSz.set(qn("w:orient"), "landscape")
    elif pgSz.get(qn("w:orient")) is not None:
        del pgSz.attrib[qn("w:orient")]
    typ = s.find(qn("w:type"))
    if typ is None:
        typ = OxmlElement("w:type"); s.insert(0, typ)
    typ.set(qn("w:val"), "nextPage")
    return s


def cell_border(cell, **edges):
    tcPr = cell._tc.get_or_add_tcPr()
    b = tcPr.find(qn("w:tcBorders"))
    if b is None:
        b = OxmlElement("w:tcBorders"); tcPr.append(b)
    for edge, (sz, val) in edges.items():
        e = b.find(qn(f"w:{edge}"))
        if e is None:
            e = OxmlElement(f"w:{edge}"); b.append(e)
        e.set(qn("w:val"), val); e.set(qn("w:sz"), str(sz)); e.set(qn("w:space"), "0"); e.set(qn("w:color"), "000000")


def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    s = OxmlElement("w:shd"); s.set(qn("w:val"), "clear"); s.set(qn("w:color"), "auto"); s.set(qn("w:fill"), fill)
    tcPr.append(s)


NUMERIC = re.compile(r"^[\s\[\]\(\)−\-–+0-9.,%<>=≥≤×·/pP]*$")


def format_table(t):
    tbl = t._tbl
    tblPr = tbl.tblPr
    # remove pandoc table style borders, set full width
    for tag in ("w:tblStyle", "w:tblBorders", "w:tblLook"):
        e = tblPr.find(qn(tag))
        if e is not None:
            tblPr.remove(e)
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement(f"w:{edge}"); e.set(qn("w:val"), "nil"); borders.append(e)
    tblPr.append(borders)
    tblW = tblPr.find(qn("w:tblW"))
    if tblW is None:
        tblW = OxmlElement("w:tblW"); tblPr.append(tblW)
    tblW.set(qn("w:type"), "dxa"); tblW.set(qn("w:w"), str(int(LAND_TEXT_W.twips) - 100))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "fixed"); tblPr.append(lay)

    rows = t.rows
    ncol = len(t.columns)
    # content-proportional fixed column widths over the landscape text width
    # widths: every column at least fits its longest word; extra space goes to long-text columns
    CH = 100  # approx. twips per character at 10 pt Times New Roman (bold header slightly wider)
    total_tw = int(LAND_TEXT_W.twips) - 100
    minw, desire = [], []
    for j in range(ncol):
        cells = [rows[i].cells[j].text.strip() for i in range(len(rows))]
        longest_word = max([len(w) for c in cells for w in c.split()] + [3])
        body_len = max([len(c) for c in cells[1:]] + [1])
        hdr_len = len(cells[0])
        mn = (longest_word + 2) * CH * (1.1 if True else 1)
        de = max(mn, min(max(body_len, hdr_len / 2.2), 48) * CH + 2 * CH)
        minw.append(mn); desire.append(de)
    if sum(desire) <= total_tw:
        widths = [d + (total_tw - sum(desire)) * d / sum(desire) for d in desire]
    elif sum(minw) <= total_tw:
        extra = [d - m for d, m in zip(desire, minw)]
        widths = [m + (total_tw - sum(minw)) * e / max(sum(extra), 1) for m, e in zip(minw, extra)]
    else:
        widths = [total_tw * m / sum(minw) for m in minw]
    widths = [int(w) for w in widths]
    grid = tbl.find(qn("w:tblGrid"))
    if grid is not None:
        for gc, w in zip(grid.findall(qn("w:gridCol")), widths):
            gc.set(qn("w:w"), str(w))
    for row in rows:
        for j, cell in enumerate(row.cells):
            tcPr = cell._tc.get_or_add_tcPr()
            tcW = tcPr.find(qn("w:tcW"))
            if tcW is None:
                tcW = OxmlElement("w:tcW"); tcPr.insert(0, tcW)
            tcW.set(qn("w:w"), str(widths[j])); tcW.set(qn("w:type"), "dxa")
    # decide numeric columns from body rows
    numeric = []
    for j in range(ncol):
        vals = [rows[i].cells[j].text.strip() for i in range(1, len(rows))]
        numeric.append(j > 0 and all(NUMERIC.match(v) for v in vals if v))
    for i, row in enumerate(rows):
        trPr = row._tr.get_or_add_trPr()
        cant = OxmlElement("w:cantSplit"); trPr.append(cant)
        if i == 0:
            hdr = OxmlElement("w:tblHeader"); trPr.append(hdr)
        for j, cell in enumerate(row.cells):
            edges = {}
            if i == 0:
                edges["top"] = (12, "single"); edges["bottom"] = (6, "single")
                shade(cell, "E8EEF6")
            if i == len(rows) - 1:
                edges["bottom"] = (12, "single")
            if edges:
                cell_border(cell, **edges)
            tcPr = cell._tc.get_or_add_tcPr()
            mar = OxmlElement("w:tcMar")
            for side, v in (("top", 40), ("bottom", 40), ("left", 90), ("right", 90)):
                m = OxmlElement(f"w:{side}"); m.set(qn("w:w"), str(v)); m.set(qn("w:type"), "dxa"); mar.append(m)
            tcPr.append(mar)
            va = OxmlElement("w:vAlign"); va.set(qn("w:val"), "center"); tcPr.append(va)
            for p in cell.paragraphs:
                pf = p.paragraph_format
                pf.space_before = Pt(0); pf.space_after = Pt(0)
                pf.line_spacing = 1.0
                pf.first_line_indent = Cm(0)
                if i == 0:
                    pf.alignment = WD_ALIGN_PARAGRAPH.CENTER if j > 0 else WD_ALIGN_PARAGRAPH.LEFT
                else:
                    pf.alignment = WD_ALIGN_PARAGRAPH.CENTER if numeric[j] else WD_ALIGN_PARAGRAPH.LEFT
                for r in p.runs:
                    r.font.name = FONT; set_font(r._r.get_or_add_rPr())
                    r.font.size = Pt(10)
                    if i == 0:
                        r.font.bold = True
        # keep table rows together with the next row (keeps short tables on one page)
        for cell in row.cells:
            for p in cell.paragraphs:
                p.paragraph_format.keep_with_next = i < len(rows) - 1


def bold_label(p, pattern):
    """Make a leading label like 'Fig. 3.' bold inside a caption paragraph."""
    runs = p.runs
    if not runs:
        return
    full = "".join(r.text for r in runs)
    m = re.match(pattern, full)
    if not m:
        return
    label = m.group(0)
    first = runs[0]
    if first.text.startswith(label):
        rest = first.text[len(label):]
        first.text = label; first.font.bold = True
        if rest:
            new = copy.deepcopy(first._r); first._r.addnext(new)
            from docx.text.run import Run
            nr = Run(new, p); nr.text = rest; nr.font.bold = False


def add_page_number_footer(section):
    footer = section.footer
    footer.is_linked_to_previous = False
    p = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run()
    for kind, txt in (("begin", None), (None, "PAGE"), ("end", None)):
        if kind:
            fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), kind); r._r.append(fc)
        else:
            it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = txt; r._r.append(it)
    r.font.name = FONT; r.font.size = Pt(10)


def line_numbers(sectPr):
    ln = sectPr.find(qn("w:lnNumType"))
    if ln is None:
        ln = OxmlElement("w:lnNumType")
        pgSz = sectPr.find(qn("w:pgMar"))
        (pgSz.addnext(ln) if pgSz is not None else sectPr.append(ln))
    ln.set(qn("w:countBy"), "1"); ln.set(qn("w:restart"), "continuous"); ln.set(qn("w:distance"), "283")


# ---------------------------------------------------------------- main
def main():
    raw = SRC.read_text(encoding="utf-8")
    tmp_docx = OUT.with_suffix(".pandoc.docx")
    run_pandoc(preprocess(raw), tmp_docx)
    doc = Document(tmp_docx)

    # ---- styles
    st = doc.styles
    for s in st:
        try:
            if s.type in (1, 2):  # paragraph / character
                s.font.name = FONT
                set_font(s.element.get_or_add_rPr())
                if s.font.color is not None and s.type == 1:
                    s.font.color.rgb = RGBColor(0, 0, 0)
        except Exception:
            pass
    # document defaults
    rpr_default = doc.styles.element.find(qn("w:docDefaults")).find(qn("w:rPrDefault")).find(qn("w:rPr"))
    set_font(rpr_default)
    for name in ("Normal", "Body Text", "First Paragraph", "Compact"):
        if name in [s.name for s in st]:
            s = st[name]
            style_font(s, 12, align=WD_ALIGN_PARAGRAPH.JUSTIFY, before=0, after=6)
            s.paragraph_format.line_spacing = 1.5
    style_font(st["Title"], 14, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, before=0, after=12)
    st["Title"].paragraph_format.line_spacing = 1.15
    style_font(st["Heading 1"], 14, bold=True, align=WD_ALIGN_PARAGRAPH.LEFT, before=18, after=6)
    style_font(st["Heading 2"], 12, bold=True, align=WD_ALIGN_PARAGRAPH.LEFT, before=12, after=6)
    for h in ("Heading 1", "Heading 2"):
        st[h].paragraph_format.keep_with_next = True
        st[h].paragraph_format.line_spacing = 1.15
    for cap in ("Image Caption", "Table Caption", "Caption"):
        if cap in [s.name for s in st]:
            style_font(st[cap], 11, align=WD_ALIGN_PARAGRAPH.LEFT, before=4, after=10)
            st[cap].font.italic = False
            st[cap].paragraph_format.line_spacing = 1.15
    if "Captioned Figure" in [s.name for s in st]:
        st["Captioned Figure"].paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        st["Captioned Figure"].paragraph_format.keep_with_next = True

    body = doc.element.body
    blocks = [el for el in body if el.tag in (qn("w:p"), qn("w:tbl"))]
    from docx.text.paragraph import Paragraph
    from docx.table import Table

    # ---- paragraph-level fixes and float classification
    is_float = []
    in_refs = False
    prev_was_table = False
    for el in blocks:
        f = False
        if el.tag == qn("w:tbl"):
            t = Table(el, doc)
            format_table(t)
            f = True
            prev_was_table = True
        else:
            p = Paragraph(el, doc)
            txt = para_text(el).strip()
            sname = p.style.name if p.style is not None else ""
            if sname.startswith("Heading"):
                in_refs = txt.lower() == "references"
                for r in p.runs:
                    r.font.color.rgb = RGBColor(0, 0, 0); r.font.name = FONT
            if is_float_par(el):
                f = True
                for shp in el.iter(qn("wp:extent")):
                    cx, cy = int(shp.get("cx")), int(shp.get("cy"))
                    maxw, maxh = int(LAND_TEXT_W) - int(Cm(0.5)), int(LAND_TEXT_H) - int(Cm(3.2))
                    sc = min(maxw / cx, maxh / cy)
                    ncx, ncy = int(cx * sc), int(cy * sc)
                    shp.set("cx", str(ncx)); shp.set("cy", str(ncy))
                    for ext in el.iter(qn("a:ext")):
                        if ext.get("cx"):
                            ext.set("cx", str(ncx)); ext.set("cy", str(ncy))
                p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
                p.paragraph_format.keep_with_next = True
                p.paragraph_format.line_spacing = 1.0
            elif re.match(r"^Fig\. \d+\.", txt):
                f = True
                bold_label(p, r"^Fig\. \d+\.")
                p.paragraph_format.line_spacing = 1.15
                p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for r in p.runs:
                    r.font.size = Pt(11); r.font.italic = False
            elif re.match(r"^Table A?\d+[a-z]?\.", txt):
                f = True
                p.paragraph_format.keep_with_next = True
                p.paragraph_format.line_spacing = 1.15
                p.paragraph_format.space_before = Pt(6); p.paragraph_format.space_after = Pt(4)
                p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for r in p.runs:
                    r.font.size = Pt(11)
            elif prev_was_table and txt.startswith("Notes"):
                f = True
                p.paragraph_format.line_spacing = 1.0
                p.paragraph_format.space_before = Pt(3); p.paragraph_format.space_after = Pt(12)
                p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for r in p.runs:
                    r.font.size = Pt(9.5)
            if in_refs and not sname.startswith("Heading") and txt:
                pf = p.paragraph_format
                pf.left_indent = Cm(1.27); pf.first_line_indent = Cm(-1.27)
                pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
                pf.line_spacing = 1.5
            prev_was_table = False
        is_float.append(f)

    # tables: keep caption with table; notes follow
    # ---- landscape sections: each maximal run of float blocks becomes a landscape section
    final_sectPr = body.find(qn("w:sectPr"))
    pgMar = final_sectPr.find(qn("w:pgMar"))
    if pgMar is None:
        pgMar = OxmlElement("w:pgMar")
        pgSz0 = final_sectPr.find(qn("w:pgSz"))
        (pgSz0.addnext(pgMar) if pgSz0 is not None else final_sectPr.append(pgMar))
        for k in ("w:header", "w:footer"):
            pgMar.set(qn(k), "709")
        pgMar.set(qn("w:gutter"), "0")
    for k, v in (("w:top", MARGIN), ("w:bottom", MARGIN), ("w:left", MARGIN), ("w:right", MARGIN)):
        pgMar.set(qn(k), str(int(v.twips)))
    template = copy.deepcopy(final_sectPr)
    line_numbers(template)

    n = len(blocks)
    runs = []  # (start, end, landscape)
    i = 0
    while i < n:
        j = i
        while j + 1 < n and is_float[j + 1] == is_float[i]:
            j += 1
        runs.append((i, j, is_float[i]))
        i = j + 1

    def last_par_of(start, end):
        if blocks[end].tag == qn("w:p"):
            return blocks[end]
        # section ends with a table: insert a tiny empty paragraph after it
        p = OxmlElement("w:p"); blocks[end].addnext(p)
        pPr = OxmlElement("w:pPr"); p.append(pPr)
        sp = OxmlElement("w:spacing"); sp.set(qn("w:before"), "0"); sp.set(qn("w:after"), "0")
        sp.set(qn("w:line"), "20"); sp.set(qn("w:lineRule"), "exact"); pPr.append(sp)
        return p

    for idx, (s, e, land) in enumerate(runs[:-1]):
        lp = last_par_of(s, e)
        pPr = lp.find(qn("w:pPr"))
        if pPr is None:
            pPr = OxmlElement("w:pPr"); lp.insert(0, pPr)
        sp = make_sectPr(template, land)
        if land:
            pm = sp.find(qn("w:pgMar"))
            pm.set(qn("w:top"), str(int(MARGIN.twips))); pm.set(qn("w:bottom"), str(int(MARGIN.twips)))
        pPr.append(sp)
    # final section
    last_land = runs[-1][2]
    new_final = make_sectPr(template, last_land)
    for child in list(final_sectPr):
        if child.tag in (qn("w:headerReference"), qn("w:footerReference")):
            new_final.insert(0, child)
    body.replace(final_sectPr, new_final)

    # page numbers in first section footer (later sections inherit)
    doc = Document(_save(doc, tmp_docx))
    add_page_number_footer(doc.sections[0])
    for sec in doc.sections[1:]:
        sec.footer.is_linked_to_previous = True
    doc.save(OUT)
    tmp_docx.unlink()
    n_land = sum(1 for r in runs if r[2])
    print(f"wrote {OUT}  sections={len(runs)}  landscape={n_land}")


def _save(doc, path):
    doc.save(path)
    return path


if __name__ == "__main__":
    main()
