# Replication package: Global aircraft-reported GNSS degradation in civil aviation, 2022–2026

This package accompanies the article:

> Üzülmez, M. (2026). *From localised to endemic: A global spatiotemporal analysis of aircraft-reported GNSS degradation in civil aviation, 2022–2026*. Manuscript submitted to *Safety Science*.

It contains the analysis code, the derived (aggregated) datasets, all result tables and the figures. It does **not** redistribute the raw GPSJam daily files or the full hex-day panel built from them, because the provider publishes no licence for redistribution. The download script retrieves the raw files from the public source.

- **DOI:** [to be added after deposit]
- **Version:** 1.0 (15 November 2026)
- **Contact:** Mevlüt Üzülmez, Department of Aviation Management, Faculty of Aeronautics and Astronautics, Erciyes University, Kayseri, Türkiye. ORCID [0000-0002-4606-7468](https://orcid.org/0000-0002-4606-7468)

## Contents

```
scripts/                     analysis pipeline (Python), run in numerical order
data/hexes.parquet           H3 resolution-4 cell metadata: centroid, reporting region, country (ISO3)
data/raw/gpsjam_manifest.csv provider manifest (dates, incomplete-day flags, data source), downloaded 14 Nov 2026
data/raw/ourairports_airports.csv  OurAirports open data (public domain), downloaded 14 Nov 2026
data/raw/ne/                 Natural Earth 1:50m admin-0 countries (public domain)
data/derived/                aggregated datasets produced by the pipeline (see below)
results/                     all result tables (CSV) of the original analysis
results/revision/            robustness, falsification and extended analyses (script 11)
figures/                     Figures 1–10 (PNG, 300 dpi)
```

### Derived datasets (`data/derived/`)

| File | Unit | Description |
|---|---|---|
| `daily_region.csv` | region × day | Observed hexes, red hexes, aircraft, degraded aircraft, aircraft in red hexes, red area (km²), red-hex share, aircraft-in-red share, incomplete-day flag, data source. Regions: Global, eight reporting regions, Levant core, Türkiye (land), Rest of world. Hex-days with ≥3 aircraft. |
| `daily_region_n10.csv` | region × day | As above, with hex-days with ≥10 aircraft. |
| `hex_year.csv` | H3 cell × year | Observed days, red days, aircraft, aircraft in red hex-days, region, country, centroid, area, share of red days. |
| `hex_year_class.csv` | H3 cell × year | As above, with the hotspot class (none / sporadic / recurrent / chronic) for cells with ≥30 observed days. |
| `hexmonth.parquet` | H3 cell × month | Observed days; red days at 5/10/20% thresholds; red days with ≥10 aircraft; aircraft; degraded aircraft (raw and minus-one corrected); aircraft in red hex-days. Incomplete days excluded. |
| `episodes.csv` | episode | Runs of consecutive red days in focal-region cells: cell index, start-day index, duration (days), event flag (1 = ended, 0 = censored), region, country, start year. |

### Definitions

- **Degraded-accuracy percentage** of a hex-day: 100 × (b − 1) / (g + b), floored at zero, where g and b are the numbers of aircraft reporting good and degraded navigation accuracy (provider's formula).
- **Red (degraded) hex-day:** percentage > 10%. Analytic sample: hex-days with g + b ≥ 3.
- **Degraded-aircraft share:** Σ(b − 1)⁺ / Σ(g + b).
- **Hotspot classes** (per cell and calendar year, ≥30 observed days): sporadic (0–10% of days red), recurrent (10–50%), chronic (>50%).
- Days are UTC. The 16 days flagged incomplete by the provider are excluded from time-series analyses.

## Reproducing the analysis

Requirements: Python 3.14 (tested) and the packages in `requirements.txt`; about 2 GB of disk space for the raw files.

```
pip install -r requirements.txt
python scripts/01_download_gpsjam.py     # downloads the raw daily files from gpsjam.org/data (≈1.5 GB)
python scripts/02_build_panel.py         # builds data/panel.parquet and data/hexes.parquet
python scripts/03_aggregate.py           # daily regional series, hex-year table, focal hex-days
python scripts/03_aggregate.py 10        # same with n ≥ 10
python scripts/04_analysis.py            # trends, typology, Markov, contagion FE, ITS events
python scripts/05_figures.py             # Figures 1–4, 7
python scripts/06_turkey.py              # Türkiye zones and Ankara-cluster sensitivity
python scripts/08_extended.py            # airports, episodes, distance decay, dynamic events, nowcast
python scripts/11_revision.py            # robustness and falsification analyses (parts A–F)
python scripts/11_revision.py D2         # fixed-composition event check
python scripts/09_figures_ext.py         # Figures 5, 6, 8, 9, 10
```

Scripts 07, 10 and 12 generate the manuscript tables and the formatted manuscript and are included for completeness. The GPSJam archive is updated daily. Runs after 14 November 2026 will contain additional days, and the provider may revise earlier files, so set the end date in `01_download_gpsjam.py` to reproduce the published numbers exactly. The nowcast training sample uses `random_state=1`.

## Sources and licences

- **GPSJam** daily H3 maps (https://gpsjam.org/data/), compiled by J. Wiseman from ADS-B Exchange and airplanes.live data. No redistribution licence is published, so the raw files are not included.
- **OurAirports** (https://ourairports.com/data/): public domain.
- **Natural Earth** (https://www.naturalearthdata.com/): public domain.
- **This package:** code under the MIT License; derived data, results and figures under CC BY 4.0 (see `LICENSE`).

## Responsible use

All data are aggregated to cells of about 1,770 km² and to UTC days. The package derives no emitter locations. Exposure figures describe airspace conditions as reported by aircraft. They are not assessments of the safety of any airport, operator or state.
